# Repeated six-qutrit layers for historical FX forecasts

The two-page note uses the sealed 24-fit score report. The interactive circuit viewer exposes the exact trained stages used in the note.

Unpack the source archive into a fresh directory. Run the following commands from that directory.

```sh
python3 -B tables.py score.json tables.tex
mkdir render
export SOURCE_DATE_EPOCH=1795248000 FORCE_SOURCE_DATE=1
pdflatex -halt-on-error -interaction=nonstopmode -output-directory=render compact.tex
pdflatex -halt-on-error -interaction=nonstopmode -output-directory=render compact.tex
```

The Python script checks the SHA-256 of `score.json` before typesetting both tables. It creates a new output file. The source archive includes only the manuscript, table generator, and public aggregate. Independent score verification, circuit traces and numerical contraction results are available in the project lab. [Study and reproducibility details](https://amelie-iska.github.io/phaseweave-lab/circuit-depth.html)
