"""Typeset the fixed-seed scores directly from the sealed aggregate."""
import argparse
import hashlib
import json
from pathlib import Path


SCORE_SHA256 = "4fcd2858faab9eae2e5127bc3733f2d655c5a956295a3251f186c554ba31df00"
PANELS = (
    ("afternoon", "November afternoon"), ("test", "October"), ("new_asset", "CHF"),
    ("stress", "September stress"), ("validation", "Validation"),
)
ARMS = {"entangling": "Entangling", "product": "Product", "dephased": "Dephased", "maxplus": "Max-plus"}


def tabular_row(values):
    return " & ".join(map(str, values)) + r" \\"


def rows(report):
    contrast = []
    for panel, title in PANELS:
        split = report["splits"][panel]
        difference = split["versus_depth_one"]["4"]["entangling"]["mean_over_fixed_seeds"]
        contrast.append(tabular_row((title, f"{split['rows']:,}", f"${difference['delta_mae_bps']:+.6f}$",
                                     f"$[{difference['lower_95']:+.6f}, {difference['upper_95']:+.6f}]$")))
    scores = []
    for depth in report["depths"]:
        for arm, title in ARMS.items():
            entries = []
            for panel, _ in PANELS:
                cells = report["splits"][panel]["cells"]
                errors = [cells[f"tokengt-w6-q3-d{depth}-{arm}-{seed}"]["mae_bps"] for seed in report["seeds"]]
                entries.append(f"{sum(errors) / len(errors):.6f}")
            scores.append(tabular_row((depth, title, *entries)))
    scores.append(r"\midrule")
    persistence = [f"{report['splits'][panel]['cells']['persistence']['mae_bps']:.6f}" for panel, _ in PANELS]
    scores.append(tabular_row(("--", "Persistence", *persistence)))
    return "\n".join([
        r"\newcommand{\DepthContrastRows}{", *contrast, "}",
        r"\newcommand{\DepthScoreRows}{", *scores, "}", "",
    ])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("score", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    raw = args.score.read_bytes()
    if hashlib.sha256(raw).hexdigest() != SCORE_SHA256:
        parser.error("score bytes do not match the sealed study")
    with args.output.open("x", encoding="ascii") as output:
        output.write(rows(json.loads(raw)))


if __name__ == "__main__":
    main()
