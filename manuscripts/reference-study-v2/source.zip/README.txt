Build both editions with latexmk -pdf compact.tex extended.tex.
