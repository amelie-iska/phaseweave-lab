# Directed exchange-rate cycle addenda

The compact report and extended supplement describe the same 26-fit pilot. They supplement the PhaseWeave research manuscript. Both figures are original vector plots of aggregate results.

## Rebuild the reports

From the source bundle, using Python 3.10+ and TeX Live with latexmk, PGFPlots, standalone, booktabs and Latin Modern:

```sh
python3 -B build_tables.py --campaign receipts --audit receipts/audit.json --out .
latexmk -pdf -halt-on-error transfer-figure.tex paired-figure.tex
latexmk -pdf -halt-on-error compact.tex extended.tex
```

The 2,240 rows in `all-metrics.csv` are model, split, cadence, mask, route length and tenor summaries. The 120 rows in `all-paired.csv` include observation-weighted and day-equal estimates, resampled day intervals, and the five-second-origin subset sensitivity. The two-seed GAT with token attention figures in the headline are the arithmetic means of the two individual test MAEs. The TokenGT fit drawn in Figure 1 was selected using the minimum September validation macro error, prior to inspecting its October performance.

The frozen receipt set contains aggregate results, protocol metadata and artifact hashes. The rebuild reads neither source quotes nor individual predictions. The intended public navigation is the [cycle results](https://amelie-iska.github.io/phaseweave-lab/fx-cycles.html), [dataset contract](https://amelie-iska.github.io/phaseweave-lab/downloads/fx-cycle-pilot.md), [independent audit](https://amelie-iska.github.io/phaseweave-lab/fx-cycle-pilot-audit-v1.json) and [exact K4 witness](https://amelie-iska.github.io/phaseweave-lab/k4-transport.html).

## Refit from the project environment

The following uses an authorized checkout of the original project, the existing research environment and its two archive manifests. Run only with fresh output paths. Define `DATASET_DIR`, `PLAN_FILE`, and `NEW_RUN_DIR` in your shell. The training wrapper creates `cadence-1` and `cadence-5` under the new run directory.

```sh
python3 -B research/curate_fx_cycle_dataset.py freeze --plan "$PLAN_FILE"
python3 -B research/curate_fx_cycle_dataset.py curate --plan "$PLAN_FILE" --output "$DATASET_DIR"
./scripts/train_fx_cycles.sh "$DATASET_DIR" 91d2f42fe5b286fecf40c46e66bb97d2cb64f6dca59339a4b78f3406d7c80d15 "$NEW_RUN_DIR"
```

Record versions and verify the dataset hash before scoring. The study used Torch 2.8.0+cu128 and CUDA, with classical circuit simulation on the GPU. Raw quote archives retain their provider terms. No raw quote rows, individual predictions or model weights are contained in this source bundle.

## Evidence identities

The dataset manifest is `91d2f42fe5b286fecf40c46e66bb97d2cb64f6dca59339a4b78f3406d7c80d15`. The pre-outcome curation plan is `d0e53fe406b27de9a03614de06260079b0a2b2ad0d6c242beb245bdb6b400ba5`. The benchmark config is `aed89e5dfb3c16b5d24218dc66850cf5e9dca285b6631fc2533a5b46012544ff`. The audit SHA-256 is `88d15e7d85ec0592687ce7a91764a22d5c8ccc820c759edc2fa620e831ddf453`. Each protocol records the runner and model hashes; each completion receipt identifies the split metrics and frozen selection. The script checks these aggregate identities before generating its tables.

The finite quaternion and localization witness can be replayed independently with `python3 -B check_k4_localization.py`. The bundled `k4-witness.json` captures the verified reference. Floating-point roundoff in its continuous-gauge cross-check may vary across platforms.
