"""Recreate typeset numbers from signed-off aggregate receipts. Never opens quote/prediction rows."""
import argparse,csv,hashlib,json
from pathlib import Path
P=argparse.ArgumentParser();P.add_argument('--campaign',type=Path,required=True);P.add_argument('--audit',type=Path,required=True);P.add_argument('--out',type=Path,default=Path('.'));a=P.parse_args()
out=a.out;out.mkdir(parents=True,exist_ok=True)
def check(path,expected=None):
 b=path.read_bytes()
 if expected and hashlib.sha256(b).hexdigest()!=expected:raise ValueError(path.name)
 return json.loads(b)
def table(file, rows):
 (out/file).write_text('\n'.join(' & '.join(map(str,r))+r' \\' for r in rows)+'\n')
def csvout(file,rows):
 with (out/file).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
audit=check(a.audit,'88d15e7d85ec0592687ce7a91764a22d5c8ccc820c759edc2fa620e831ddf453');metrics={};selections={};all_rows=[];pairs=[]
for step,folder in [(1,'one'),(5,'five')]:
 run=audit['runs'][str(step)];p=a.campaign/folder
 done=check(p/'completed.json',run['completed_sha256']);sel=check(p/'selection.json',done['selection_sha256'])['learned'];protocol=check(p/'protocol.json',run['protocol_sha256'])
 assert protocol['dataset_manifest_sha256']==audit['dataset_manifest_sha256']
 selections[step]=sel;metrics[step]={}
 for split in ('stress','test','new_asset'):
  data=check(p/(split+'-metrics.json'),done['split_metrics_sha256'][split]);metrics[step][split]=data['available']
  for scope in ['available','one_and_five_second_common']:
   for model,ls in data[scope].items():
    for length,ts in ls.items():
     for tenor,m in ts.items():
      row=dict(cadence_s=step,split=split,mask=scope,model=model,length=length,horizon_s=tenor)
      row.update({k:v for k,v in m.items() if k!='delta_interval'});row.update(m['delta_interval']);all_rows.append(row)
for name,items in audit['comparisons'].items():
 for item in items:
  for length,tenors in item['by_route_length_and_tenor'].items():
   for tenor,v in tenors.items():
    pairs.append(dict(contrast=name,split=item['split'],cadence_s=item.get('cadence_seconds',''),patch=item.get('patch',''),seed=item['seed'],length=int(length),horizon_s=int(tenor),pairs=v['paired_directed_route_origins'],origins=v['origins'],days=v['utc_day_blocks'],mean=v['observation_weighted_mean'],low=v['observation_weighted_day_bootstrap_95'][0],high=v['observation_weighted_day_bootstrap_95'][1],day_equal_mean=v['day_equal_weight_mean'],day_equal_low=v['day_equal_weight_bootstrap_95'][0],day_equal_high=v['day_equal_weight_bootstrap_95'][1],days_left_wins=v['days_with_lower_mae_for_left'],grid_pairs=v['five_second_origin_grid_sensitivity']['paired_directed_route_origins'],grid_delta=v['five_second_origin_grid_sensitivity']['mae_delta']))
csvout('all-metrics.csv',all_rows);csvout('all-paired.csv',pairs)
selected=min(selections[1],key=lambda k:min(selections[1][k]['validation_macro_mae_by_epoch_log_bps']));assert selected=='tokengt-classical-tropical-20261122'
methods=['persistence','ridge','hgb',selected];short=[];fig=[];long=[]
for split,title,length in [('test','K4',3),('test','K4',4),('new_asset','CHF K5',3),('new_asset','CHF K5',4),('new_asset','CHF K5',5)]:
 def m(k,t=1):return metrics[1][split][k][str(length)][str(t)]
 vals=[m(k)['mae_log_bps'] for k in methods];short.append([title,str(length),f"{m('ridge')['observations']:,}",*[f'{v:.4f}' for v in vals]])
 fig.append(' '.join(map(str,[len(short),*vals])))
 for tenor in [1,5,15,60,300]:
  long.append([title,length,tenor,f"{m('ridge',tenor)['observations']:,}",*[f"{m(k,tenor)['mae_log_bps']:.4f}" for k in methods]])
table('native.tex',short);table('tenors.tex',long);(out/'transfer.dat').write_text('x Persistence Ridge HGB TokenGT\n'+'\n'.join(fig)+'\n')
def port(r):
 return ('K4' if r['split']=='test' else 'CHF K5',r['length'],str(r['seed'])[-2:],r['pairs'],r['mean'],r['low'],r['high'])
for name,f in [('cadence_5s_minus_1s','cadence'),('coherent_minus_classical','coherence')]:
 rows=[];figs=[]
 for r in pairs:
  if r['contrast']!=name or r['horizon_s']!=1:continue
  split,length,seed,n,d,lo,hi=port(r);prefix=r['patch'].title() if name.startswith('cadence') else str(r['cadence_s'])+' s'
  rows.append([split,length,prefix,seed,f'{n:,}',f'{d:+.4f}',f'[{lo:+.4f}, {hi:+.4f}]'])
  if f=='coherence' and r['cadence_s']==1:figs.append(f'{len(figs)+1} {d} {d-lo} {hi-d}')
 table(f+'.tex',rows)
 if figs:(out/'paired.dat').write_text('y mean lower upper\n'+'\n'.join(figs)+'\n')
rows=[]
for key,k in sorted(selections[1].items()):
 s=str(k['seed'])[-2:];arm=k['backbone'].upper().replace('_',r'\,+\,');v=min(k['validation_macro_mae_by_epoch_log_bps'])
 r=[arm,k['patch'],k['attention'],s,k['selected_epoch'],f'{v:.4f}',*[f"{metrics[1][sp][key][l]['1']['mae_log_bps']:.4f}" for sp,l in [('test','4'),('new_asset','4'),('new_asset','5')]]];rows.append(r)
table('roster.tex',rows)
