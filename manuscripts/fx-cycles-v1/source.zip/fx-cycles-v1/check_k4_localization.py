"""Exact polynomial-order and Wilson witnesses on the fixed graph K4 (stdlib)."""
from fractions import Fraction
from itertools import combinations, product
import json
import math
import random

EDGES=list(combinations(range(4),2))
ROTATIONS=((1,2,3),(0,3,2),(0,1,3),(0,2,1))
CYCLES=((0,1,2,0),(0,2,3,0),(0,1,3,0),(1,2,3,1))

def slot(v,i,j):
    return 9*v+3*i+j

def basis(t):
    """Embedded free-basis columns for branch hereditary blocks, with shared diagonals."""
    columns=[]
    for v in range(4):
        for i in range(3):
            for j in range(3):
                if i==j:
                    continue
                col=[0]*36
                col[slot(v,i,j)]=1 if i<j else t
                columns.append(col)
    for a,b in EDGES:
        i,j=ROTATIONS[a].index(b),ROTATIONS[b].index(a)
        av,bv=slot(a,i,i),slot(b,j,j)
        shared=[0]*36
        shared[av]=shared[bv]=1
        branch=[0]*36
        branch[av]=t
        columns.extend([shared,branch])
    return columns

def invariants(cols):
    a=[list(map(Fraction,row)) for row in zip(*cols)]
    pivots=0
    det=1
    for col in range(len(a[0])):
        k=next((i for i in range(pivots,len(a)) if a[i][col]),None)
        if k is None:
            continue
        if k!=pivots:
            a[k],a[pivots]=a[pivots],a[k]
            det=-det
        row=a[pivots]
        det*=row[col]
        for i in range(pivots+1,len(a)):
            v=a[i][col]
            if v:
                ratio=v/row[col]
                a[i]=[x-ratio*y for x,y in zip(a[i],row)]
        pivots+=1
    return pivots,int(det) if pivots==len(a) else 0

# Q8 labels ±1, ±i, ±j, ±k use signed integers ±1, ±2, ±3, ±4.
Q=((1,2,3,4),(2,-1,4,-3),(3,-4,-1,2),(4,3,-2,-1))
def mul(a,b):
    s=1 if a*b>0 else -1
    return s*Q[abs(a)-1][abs(b)-1]
def inverse(a): return a if abs(a)==1 else -a
def connection(k):
    U={edge:1 for edge in EDGES}
    U.update({(1,2):2,(2,3):3,(1,3):k})
    return {**U,**{(b,a):inverse(v) for (a,b),v in U.items()}}
def word(U,cycle):
    h=1
    for a,b in zip(cycle,cycle[1:]):
        h=mul(U[a,b],h)
    return h
def tr(q):return q if abs(q)==1 else 0

def signed_turns():
    # Quiver vertices are original edges, and a turn stays at a geometric vertex.
    turns=[]
    for v,star in enumerate(ROTATIONS):
        for j,n in enumerate(star):
            source=tuple(sorted((v,n)))
            target=tuple(sorted((v,star[(j-1)%3])))
            turns.append((source,target,v))
    legal=mixed=0
    for x,y,v in turns:
        for z,w,n in turns:
            if y==z:
                if v==n:legal+=1
                else:mixed+=1
    assert (len(turns),legal,mixed)==(12,12,12)
    return legal,mixed

# Independent direct complex matrices for floating-point checks with Haar SU(2) basis changes.
I=((1+0j,0j),(0j,1+0j))
M=[I,((1j,0j),(0j,-1j)),((0j,1+0j),(-1+0j,0j)),((0j,1j),(1j,0j))]
def matmul(a,b):
    return tuple(tuple(sum(a[i][k]*b[k][j] for k in range(2)) for j in range(2)) for i in range(2))
def adj(a):
    return tuple(tuple(a[j][i].conjugate() for j in range(2)) for i in range(2))
def matrix(q):
    return tuple(tuple((1 if q>0 else -1)*w for w in row) for row in M[abs(q)-1])
def random_su2(rng):
    v=[rng.gauss(0,1) for _ in range(4)]
    s=math.sqrt(sum(t*t for t in v)); a,b=complex(v[0],v[1])/s,complex(v[2],v[3])/s
    return ((a,b),(-b.conjugate(),a.conjugate()))

def main():
    ranks={str(t):invariants(basis(t)) for t in (0,1,-1,2,-2,3)}
    assert all((n==36 and abs(d)==int(t)**18) if int(t) else (n,d)==(18,0) for t,(n,d) in ranks.items())
    legal,mixed=signed_turns()
    exact=0;float_error=0.;runs=[]
    rng=random.Random(20261121)
    for k in (4,-4):
        u=connection(k)
        ref=[word(u,c) for c in CYCLES];traces=[tr(x) for x in ref]
        assert traces==[0,0,0,-1 if k>0 else 1]
        for g in product((1,-1,2,-2,3,-3,4,-4), repeat=4):
            h={(a,b):mul(mul(g[b],x),inverse(g[a])) for (a,b),x in u.items()}
            assert all(word(h,c)==mul(mul(g[c[0]],q),inverse(g[c[0]])) for c,q in zip(CYCLES,ref))
            exact+=1
        for _ in range(128):
            g=[random_su2(rng) for _ in range(4)]
            edges={(a,b):matmul(matmul(g[b],matrix(x)),adj(g[a])) for (a,b),x in u.items()}
            for path,q in zip(CYCLES,ref):
                h=I
                for a,b in zip(path,path[1:]): h=matmul(edges[a,b],h)
                expected=matmul(matmul(g[path[0]],matrix(q)),adj(g[path[0]]))
                float_error=max(float_error,max(abs(h[i][j]-expected[i][j]) for i,j in product(range(2),repeat=2)),abs((h[0][0]+h[1][1])/2-tr(q)))
        runs.append(traces)
    assert float_error<1e-12
    # Exact directed cochain identity; these integer fixtures encode no observations.
    corrected=violations=0
    for _ in range(256):
        rates={}
        for a,b in EDGES:
            mid=rng.randint(-20,20); spread=rng.randint(0,10)
            rates[a,b]=mid-spread
            rates[b,a]=-mid-spread
        loops=[sum(rates[a,b] for a,b in zip(path,path[1:])) for path in CYCLES]
        delta=loops[3]-loops[0]-loops[1]+loops[2]
        correction=rates[3,1]+rates[1,3]-rates[2,0]-rates[0,2]
        assert delta==correction
        corrected+=1; violations+=int(delta!=0)
    print(json.dumps(dict(graph="K4",coefficient_maps=ranks,legal_pairs=legal,forbidden_pairs=mixed,
                          directed_cochain_checks=corrected,nonzero_spread_corrections=violations,
                          normalized_triangle_traces=runs,exact_vertex_gauges=exact,float_vertex_gauges=256,
                          numeric_seed=20261121,max_float_matrix_or_trace_error=float_error),indent=2))
if __name__=="__main__":main()
