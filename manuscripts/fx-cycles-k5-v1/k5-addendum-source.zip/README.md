# Reproducing the K5 benchmark addendum

The source archive contains the self-contained manuscript, its editable template, the two aggregate receipts, a deterministic table generator and an independent direct-circuit mathematical check. The self-contained manuscript compiles with standard TeX Live and latexmk.

```sh
shasum -a 256 -c SHA256SUMS
python3 -B check_single_wire.py
python3 -B generate.py k5-rebuilt.tex --metrics held-out-metrics.json \
  --sha256 064fb473ba2fe5d7b11033ed560046c2652edc783e19b5374c56f3264a01b22c \
  --seal-1 a931bc89966345c4fada93404690e5d8b9e0020adb74ecefb0656c73968c27bf \
  --seal-5 ace8f8e88a296acfaa89f4e6db8f854791636041fc8498b06c6708fc21af4000 \
  --interpretation interpretation.tex
cmp k5-rebuilt.tex k5-addendum.tex
latexmk -pdf -halt-on-error k5-rebuilt.tex
```

The reported aggregate scores and all paired intervals match the separate audit within the reported tolerances. Its all-checks flag is false because the 5 s histogram-gradient-boosting CPU replay differs from the sealed backend on five of 947,200 prediction cells above the stated tolerance. The ranking table uses the sealed prediction aggregates. The per-origin training, prediction and outcome payloads remain with the licensed dataset. The compact generator averages independently scored seed MAEs for stochastic table rows and checks the exact bootstrap contrast direction. The archive's two receipt digests can be checked in SHA256SUMS.
