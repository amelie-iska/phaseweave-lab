"""Materialize a self-contained LaTeX addendum from audited aggregate scores."""
import argparse
import hashlib
import json
from pathlib import Path
from statistics import mean

MODELS = [
    ('Persistence', 'persistence', False),
    ('Ridge', 'ridge', False),
    ('Histogram gradient boosting', 'hgb', False),
    ('Hodge ridge', 'hodge_ridge', False),
    ('DLinear', 'dlinear', True),
    ('Classical MPNN, lengths 3--4', 'mpnn-classical-q3w6-softmax-short', True),
    ('Classical MPNN, lengths 3--5', 'mpnn-classical-q3w6-softmax-full', True),
    ('Coherent MPNN, lengths 3--4', 'mpnn-coherent-q3w6-softmax-short', True),
    ('Coherent MPNN, lengths 3--5', 'mpnn-coherent-q3w6-softmax-full', True),
]
SEEDS=(20261121, 20261122)


def make_tables(data):
    common, paired = [], []
    for i,(label,key,seeded) in enumerate(MODELS):
        entries = []
        for tenor in ('1','5'):
            for spacing in ('1','5'):
                keys=[f'{key}-{seed}' for seed in SEEDS] if seeded else [key]
                if data is None:
                    entries.append('---')
                    continue
                scope=data['summaries'][spacing]['common']['chf_routes']
                reference=data['summaries']['5']['common']['chf_routes']['persistence']['5'][tenor]
                items=[scope[k]['5'][tenor] for k in keys]
                assert reference['observations']>0 and all(r['observations']==reference['observations'] for r in items)
                if tenor=='1': assert reference['observations']==5432
                entries.append(f"{mean(r['mae_log_bps'] for r in items):.4f}")
        common.append((r'\midrule ' if i==5 else '')+' & '.join([label]+entries)+r'\\')
    for patch in ('classical','coherent'):
        for seed in SEEDS:
            entries=[]
            for spacing in (1,5):
                if data is None:
                    entries.append('---')
                    continue
                key=f'mpnn-{patch}-q3w6-softmax-'
                rows=[r for r in data['paired_contrasts'] if r['kind']=='five_leg_supervision'
                      and r['cadence_seconds']==spacing and r['left']==f'{key}full-{seed}'
                      and r['right']==f'{key}short-{seed}']
                assert len(rows)==1
                cell=rows[0]['available_chf_routes']['5']['1']
                assert cell['pairs']=={1:8920,5:5432}[spacing] and cell['utc_day_blocks']==5
                raw=data['summaries'][str(spacing)]['available']['chf_routes']
                check=raw[f'{key}full-{seed}']['5']['1']['mae_log_bps']-raw[f'{key}short-{seed}']['5']['1']['mae_log_bps']
                assert abs(check-cell['delta_mae'])<1e-7
                entries.append(f"${cell['delta_mae']:+.4f}\\;[{cell['lower_95']:+.5f}, {cell['upper_95']:+.5f}]$")
            paired.append(' & '.join([patch.capitalize(),str(seed)]+entries)+r'\\')
    return '\n'.join(common), '\n'.join(paired)


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('output',type=Path)
    ap.add_argument('--metrics',type=Path)
    ap.add_argument('--sha256')
    ap.add_argument('--seal-1')
    ap.add_argument('--seal-5')
    ap.add_argument('--interpretation',type=Path)
    args=ap.parse_args()
    data=None
    if args.metrics:
        raw=args.metrics.read_bytes()
        assert args.interpretation and len(args.sha256 or '')==64 and hashlib.sha256(raw).hexdigest()==args.sha256
        data=json.loads(raw)
        assert data['format']=='phaseweave.fx-cycle-k5-scores.v1'
        assert data['cadence_seals_sha256']=={'1':args.seal_1,'5':args.seal_5}
        assert all(len(h)==64 for h in data['cadence_seals_sha256'].values())
    text=Path(__file__).with_name('k5-template.tex').read_text()
    t1,t2=make_tables(data)
    txt=args.interpretation.read_text() if args.interpretation else 'Awaiting independently sealed aggregate scores. The headline tables and contrast directions were fixed before test scores arrived.'
    provenance='Draft uses the registered study protocol. The score panel awaits verified seals.' if not data else ('SHA-256 of the aggregate score receipt\\par {\\ttfamily\\footnotesize '+args.sha256+'}\\par')
    for marker,sub in [('COMMON',t1),('PAIRED',t2),('INTERPRETATION',txt),('PROVENANCE',provenance)]:
        text=text.replace(f'%%{marker}%%',sub)
    args.output.write_text(text)
