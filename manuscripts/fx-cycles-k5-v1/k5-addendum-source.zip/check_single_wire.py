"""Compare a dense circuit with the marginal formula on two fixed mathematical inputs."""
from cmath import exp
from itertools import product
from math import cos, exp as real_exp, pi, prod, sqrt


def compare(q, w):
    angles = [0.23 + 0.09 * i for i in range(w)]
    mixers = [(-1) ** i * (0.61 + 0.03 * i) for i in range(w)]
    couplings = [(i + 1) / (w + 1) for i in range(w - 1)]
    clock = [cos(2 * pi * s / q) for s in range(q)]
    p = []
    for a in angles:
        weights = [real_exp(cos(a - 2 * pi * s / q)) for s in range(q)]
        p.append([x / sum(weights) for x in weights])
    labels = list(product(range(q), repeat=w))
    state = []
    for z in labels:
        diagonal = sum(angles[i] * clock[s] for i, s in enumerate(z))
        two_site = sum(k * z[i] * z[i+1] for i, k in enumerate(couplings))
        state.append(sqrt(prod(p[i][s] for i,s in enumerate(z))) * exp(1j * (diagonal + 2*pi*two_site/q)))
    for i, theta in enumerate(mixers):
        stride = q ** (w - i - 1)
        c = (exp(1j * theta) - 1) / q
        for first in range(0,len(state),q*stride):
            for off in range(stride):
                ids = [first + off + v*stride for v in range(q)]
                add = c * sum(state[j] for j in ids)
                for j in ids:
                    state[j] += add
    dense = [sum(abs(v)**2 * clock[z[i]] for z,v in zip(labels,state)) for i in range(w)]
    marginal = []
    for i, theta in enumerate(mixers):
        c = (exp(1j*theta)-1)/q
        observable = 0j
        for s,t in product(range(q),repeat=2):
            rho = sqrt(p[i][s]*p[i][t]) * exp(1j*angles[i]*(clock[s]-clock[t]))
            for j in (i-1,i+1):
                if 0<=j<w:
                    kappa = couplings[min(i,j)]
                    rho *= sum(p[j][r]*exp(2j*pi*kappa*(s-t)*r/q) for r in range(q))
            for u in range(q):
                observable += clock[u] * (int(u==s)+c) * rho * (int(u==t)+c).conjugate()
        assert abs(observable.imag)<1e-12
        marginal.append(observable.real)
    return max(abs(x-y) for x,y in zip(dense,marginal))


if __name__=='__main__':
    for q,w in ((3,6),(5,6)):
        residual = compare(q,w)
        print(f'radix={q} wires={w} max_abs_clock_error={residual:.3e}')
        assert residual < 1e-12
