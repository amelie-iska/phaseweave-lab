Build with latexmk -pdf compact.tex extended.tex.
