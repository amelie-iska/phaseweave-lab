# Gauge benchmark manuscript sources

Both editions read the same generated table and interpretation. The independent verifier receipt contains only aggregate scientific measures and digests. The phase-preserving register stores four real amplitudes in a classical unitary simulation.

## Rebuild the papers

Read the audit hash from SHA256SUMS. Run the generator against the bundled receipt using a fresh path and compare output bytes with table.tex. Existing source and result files are preserved.

    python3 generate_table.py verified-receipt.json --expect-sha256 AUDIT_SHA256 --output /tmp/gauge-table-fresh.tex
    cmp table.tex /tmp/gauge-table-fresh.tex
    latexmk -pdf -outdir=/tmp/gauge-compact-build compact.tex
    latexmk -pdf -outdir=/tmp/gauge-extended-build extended.tex

## Reproduce a fit and independent score

Use the existing PhaseWeave research environment and a fresh output directory. The registered fixture manifest digest is 9b768fe42c4a298e4d481d41db27f99930e59261f4133b665ad7542e65e5017f. The fixture, fit and freeze steps use the scripts from this study's registration. Direct the output of both independent checks to fresh files.

    python -B research/gauge_fixture.py generate --output "$FIXTURE"
    python -B research/verify_gauge_benchmark.py fixture --fixture "$FIXTURE" --output "$FRESH/fixture-audit.json"
    python -B research/train_gauge_benchmark.py fit --device cuda --fixture "$FIXTURE" --run "$FRESH/run"
    python -B research/train_gauge_benchmark.py freeze --device cuda --fixture "$FIXTURE" --run "$FRESH/run"
    python -B research/verify_gauge_benchmark.py verify --fixture "$FIXTURE" --run "$FRESH/run" --prediction-seal-sha256 "$SEAL" --output "$FRESH/verified.json"

Set SEAL to the independently retained SHA-256 of prediction-freeze.json before scoring. The explicit seal establishes the score boundary. Runtime, floating-point kernel and selected weights can depend on the software and hardware environment. Checkpoints and per-example predictions stay with the experiment.
