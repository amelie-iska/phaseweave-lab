"""Build the shared LaTeX rows from a SHA-pinned independent verifier receipt."""
import argparse
from hashlib import sha256
import json
import math
from pathlib import Path
from statistics import mean

LABELS = {
    "raw": "Raw MLP", "bag": "Edge bag", "mpnn": "Directed MPNN", "tokengt": "TokenGT",
    "gram": "Rooted Gram MLP", "orientation": "Oriented MLP", "ququart": "Cyclic ququart + affine",
    "ququart_dephased": "Dephased + affine", "reference": "Reference traces", "wilson": "Ordered Wilson",
    "dephased": "Dephased return",
}
SEEDS = (20261129, 20261130, 20261201)
COUNTS = {"validation":4096, "test":8192, "su2":512, "su2_alternate":512}


def rows(data):
    if (data["format"] != "phaseweave.gauge-benchmark-independent.v1" or data["verified"] is not True or
            data["rows"] != COUNTS or tuple(data["learned_seeds"]) != SEEDS):
        raise ValueError("unexpected independent verifier receipt")
    fields = []
    expected = []
    for n, (arm, label) in enumerate(LABELS.items()):
        names = [f"{arm}_s{s}" for s in SEEDS] if n < 8 else [arm]
        expected.extend(names)
        numbers = []
        for name in names:
            test, stress = (data["metrics"][role][name] for role in ("test","su2"))
            pairs = stress["reflection_pairs"]
            alt = data["su2_gauge_consistency"][name]
            if not (test["rows"] == 8192 and test["by_orbit"]["groups"] == 4 and
                    stress["rows"] == 512 and pairs["pairs"] == 256 and alt["views"] == 512):
                raise ValueError("changed cohort")
            numbers.append([test["accuracy"],test["by_orbit"]["worst_group_accuracy"],stress["accuracy"],
                            pairs["pairwise_auc"],alt["decision_agreement"]])
        if not all(math.isfinite(v) and 0 <= v <= 1 for line in numbers for v in line):
            raise ValueError("invalid proportion")
        if n == 8:
            fields.append(r"\midrule")
        fields.append(" & ".join([label,*[f"{100*mean(col):.2f}" for col in zip(*numbers)]])+r" \\")
    if set(expected) != set(data["outputs"]) or len(data["outputs"]) != 27:
        raise ValueError("changed output roster")
    return "\n".join(fields)+"\n"


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("receipt", type=Path)
    p.add_argument("--expect-sha256", required=True)
    p.add_argument("--output", type=Path, required=True)
    a=p.parse_args()
    blob=a.receipt.read_bytes()
    if sha256(blob).hexdigest() != a.expect_sha256:
        p.error("receipt digest differs")
    result=rows(json.loads(blob))
    with a.output.open("x") as f:
        f.write(result)


if __name__=="__main__":
    main()
