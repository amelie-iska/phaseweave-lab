"""Validate the pinned aggregate receipts and emit the paper's three table bodies."""
import hashlib
import json
from pathlib import Path
from statistics import mean
import sys

def load(name,digest):
    b=Path(name).read_bytes()
    if hashlib.sha256(b).hexdigest()!=digest:
        raise ValueError(f"Unexpected {name}")
    return json.loads(b)

h=load("historical.json","89e167430e308580d05711c4ca74bf2a0177df706b9070e03cf4993886a0bef2")
r=load("resources.json","850ad21330b8c37f104b824b09de9c2a5366e8d2721d5b7fd5b981e7623dbe61")
assert h["format"]=="phaseweave.circuit-radix-scores.v1" and r["fit_seal_sha256"]==h["fit_seal_sha256"]
assert h["fit_seal_sha256"]=="830d85848f0ddbde38b02b349b45caf6bc3afc77cf457040384be6e2f769b9f9"
assert len(h["checkpoints"])==12 and len(r["arms"])==6
folds=["validation","stress","test","new_asset"]
radices=(2,3,5)
def write(name, rows):
    dest=Path(sys.argv[1])/name
    with dest.open("x") as f:
        for row in rows:f.write(" & ".join(map(str,row))+r" \\"+"\n")
def mae(s,q,p):
    return mean(s["cells"][f"tokengt-q{q}-{p}-{seed}"]["mae_bps"] for seed in (20261225,20261226))
rows=[]
for q in radices:
    for p in ("product","entangling"):
        row=[str(q),p.title()]
        for fold in folds:
            s=h["splits"][fold]
            assert s["rows"]==2048
            dif=mae(s,q,"entangling")-mae(s,q,"product")
            assert abs(dif-s["entangling_minus_product"][str(q)]["mean_over_fixed_seeds"]["delta_mae_bps"])<1e-12
            row.append(f"{mae(s,q,p):.5f}")
        rows.append(row)
rows.append(["","Persistence",*[f"{h['splits'][fold]['cells']['persistence']['mae_bps']:.5f}" for fold in folds]])
write("historical-rows.tex",rows)
rows=[]
for a in sorted(r["arms"],key=lambda a:(a["radix"], a["phase"]=="entangling")):
    assert a["frames"]==1024 and a["id"].endswith("20261225")
    t=a["timings"]
    rows.append([a["radix"],a["phase"].title(),*[f"{t[m]['forward']['median_ms']:.3f}" for m in ('dense','local')],
        *[f"{t[m]['forward_backward']['median_ms']:.3f}" for m in ('dense','local')],
        *[f"{t[m]['forward_backward']['additional_peak_bytes']/2**20:.2f}" for m in ('dense','local')]])
write("resource-rows.tex",rows)
rows=[]
for q in radices:
    d=h["splits"]["test"]["entangling_minus_product"][str(q)]["mean_over_fixed_seeds"]
    rows.append([q,*["$"+f"{d[k]:+.5f}"+"$" for k in ("delta_mae_bps","lower_95","upper_95")]])
write("paired-rows.tex",rows)

november = load("november.json", "3c88d9492bae6e677bf7c4fb9414f1514f5ba86d80606169593eec5c7e851a31")
assert november["format"] == "phaseweave.circuit-radix-confirmation-score.v1"
assert sum(day["scored"] for day in november["coverage"]) == november["eligible_rows"] == 2042
assert sum(day["anchors"] for day in november["coverage"]) == november["predictor_rows"] == 5120
assert sum(day["scored"] > 0 for day in november["coverage"]) == 10
assert len(november["coverage"]) == 15
result = november["results"]
persistence = result["cells"]["persistence"]["mae_bps"]
assert all(cell["mae_bps"] < persistence for key, cell in result["cells"].items() if key != "persistence")
rows = []
for q in radices:
    contrast = result["entangling_minus_product"][str(q)]
    pooled = contrast["mean_over_fixed_seeds"]
    assert abs(mae(result, q, "entangling") - mae(result, q, "product") - pooled["delta_mae_bps"]) < 1e-12
    deltas = [contrast["by_seed"][str(s)]["delta_mae_bps"] for s in (20261225, 20261226)]
    assert deltas[0] > 0 > deltas[1] and pooled["utc_day_blocks"] == 10
    interval = f"${pooled['lower_95']:+.5f}, {pooled['upper_95']:+.5f}$"
    rows.append([q, f"{mae(result, q, 'product'):.5f}", f"{mae(result, q, 'entangling'):.5f}",
                 *[f"${d:+.5f}$" for d in [*deltas, pooled["delta_mae_bps"]]], interval])
write("november-rows.tex", rows)
