# Radix, neighbor phase and exact clock readouts

`compact.pdf` is a three-page study of a width-200 TokenGT trained to predict forward and reverse FX triangle margins at one second. The registered experiment crosses three radices, two bond-phase conditions and two fixed seeds. All error values use log basis points. The memory and time values describe the circuit patch alone.

## Regenerate the paper

Run these commands in the unpacked source directory. Python 3 uses the standard library. The PDF build uses latexmk, pdfLaTeX and the packages listed in the TeX preamble.

```sh
out=$(mktemp -d)
python3 tables.py "$out"
for name in historical-rows.tex resource-rows.tex paired-rows.tex november-rows.tex; do
    cmp "$out/$name" "$name" || exit 1
done
latexmk -pdf -outdir="$out" -interaction=nonstopmode -halt-on-error compact.tex
pdfinfo "$out/compact.pdf"
```

The four tables use the included historical score, profiling and November score receipts. The generator checks all three SHA-256 digests and the common fit seal for the historical scores and profile. It verifies matched differences from seed-specific score cells, checks November coverage and writes the four TeX table bodies. The PDF has no runtime connection to the original training host. The checked-in PDF and source bundle have separate integrity identifiers.

## Research entry points

In the PhaseWeave research checkout, these entry points use the project's existing Python environment, registered benchmark configuration and authorized archived FX windows. The generator above reproduces the tables directly from aggregate results. End-to-end retraining additionally requires the archived dataset and repository modules. The example allocates a fresh output root on each invocation.

```sh
experiment=$(mktemp -d)
python3 research/train_circuit_radix.py --output "$experiment/fit" --device cuda
seal=$(shasum -a 256 "$experiment/fit/fit-seal.json" | cut -d ' ' -f1)
python3 research/score_circuit_radix.py --fit "$experiment/fit" \
    --fit-seal-sha256 "$seal" --output "$experiment/historical" --device cuda
python3 research/benchmark_clock_marginals.py --fit "$experiment/fit" \
    --seal "$seal" --output "$experiment/marginals.json" --device cuda
```

The dense and local calculation lives in `research/cyclic_clock_marginals.py`. The validation-selected checkpoints were sealed under SHA-256 `830d85848f0ddbde38b02b349b45caf6bc3afc77cf457040384be6e2f769b9f9`. The profiling receipt uses real archived training inputs with seeds and hardware recorded. Latency varies by hardware, software and load.

The separate November holdout uses `research/curate_radix_november.py` and `research/confirm_circuit_radix.py`. Forecasts are computed and sealed from predictor-only arrays before target release. The registered target clock determines which archived one-second outcomes satisfy the freshness rule. Historical fold reuse, the restricted confirmation window, and the two training seeds constrain inference.
