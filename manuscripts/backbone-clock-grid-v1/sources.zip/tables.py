"""Typeset the two tables directly from the pinned aggregate and verification receipt."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FIT = 'fdff3d2258594cb693361d0fccc3b481c30209f804b2ebfdc76a73c3c5b460e4'
SCORE = '55390f310bc847cc7d776f11e28ddfa39e42c20e0e3f5f74f0d744e230c3a9cc'
AUDIT = '991f124b4f7f6f12281aca4401ae5d98dbef5fe3e0108b8b622bd93165d5d0cd'
BACKBONES = {'gcn': 'GCN', 'gcn_tokengt': 'GCN + TokenGT', 'tokengt': 'TokenGT'}
ATTENTION = ('softmax', 'tropical')
PANELS = ('validation', 'stress', 'test', 'new_asset')


def load(name, pin):
    data = (ROOT / name).read_bytes()
    if hashlib.sha256(data).hexdigest() != pin:
        raise ValueError(f'Unexpected digest for {name}')
    return json.loads(data)


def signed(value):
    return f'{value:+.5f}'


def interval(bounds):
    return '$[' + r',\,'.join(map(signed, bounds)) + ']$'


def texrow(items):
    return ' & '.join(items) + r' \\'


def macro(name, lines):
    return '\\newcommand{\\'+name+'}{%\n'+'\n'.join(lines)+'%\n}\n'


def render():
    score, audit = load('scored.json', SCORE), load('independent.json', AUDIT)
    assert audit['verified'] is True and audit['score_sha256'] == SCORE
    assert audit['fit_seal_sha256'] == score['fit_seal_sha256'] == FIT
    assert audit['prediction_seal_sha256'] == score['prediction_seal_sha256']
    assert (score['parameters'], score['patch_parameters']) == (1538073, 1447)
    assert audit['incumbent_tokengt_softmax_checkpoint_matches'] == 24
    assert score['bootstrap_draws'] == 2500 and score['bootstrap_seed'] == 20261224
    splits = score['splits']
    main = splits['afternoon']
    assert (main['rows'], main['utc_days']) == (1329, 10)
    primary_rows, archive_rows, keys = [], [], []
    for interaction in (False, True):
        if interaction:
            primary_rows.append(r'\midrule')
        for b, name in BACKBONES.items():
            if interaction and b == 'tokengt':
                continue
            for a in ATTENTION:
                depth = f'depth4-minus-depth1:{b}:{a}:entangling'
                key = f'depth-relative-to-tokengt:{b}:{a}' if interaction else depth
                v = main['comparisons'][key]
                keys.append(key)
                primary_rows.append(texrow([name, a, '$'+signed(v['mean_delta_mae_bps'])+'$',
                                            interval(v['paired_95']), interval(v['simultaneous_95'])]))
                if not interaction:
                    archived = [signed(splits[p]['comparisons'][depth]['mean_delta_mae_bps']) for p in PANELS]
                    archive_rows.append(texrow([name, a, *['$'+x+'$' for x in archived]]))
    assert keys == main['primary_family_keys']
    return macro('primaryrows', primary_rows)+macro('archiverows', archive_rows)


if __name__ == '__main__':
    (ROOT/'tables.tex').write_text(render(), encoding='utf-8')
