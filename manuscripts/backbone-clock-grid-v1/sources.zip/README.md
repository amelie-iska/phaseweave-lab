# Six-qutrit depth across three FX backbones

The two-page research note reports the predeclared November family and the matching coherent depth contrasts for the other four panels. The inputs are aggregate score and audit receipts. Individual quotes, prediction arrays, checkpoints and private ledgers are outside this package.

In a fresh unpacked directory with Python 3 and pdfLaTeX, run the commands below. The generator checks both receipt digests, their linked fit and forecast identities, and the complete ordered November comparison roster.

~~~sh
python3 -B tables.py
mkdir render
export SOURCE_DATE_EPOCH=1795219200 FORCE_SOURCE_DATE=1 TZ=UTC
pdflatex -halt-on-error -interaction=nonstopmode -output-directory=render compact.tex
pdflatex -halt-on-error -interaction=nonstopmode -output-directory=render compact.tex
~~~

The experiment used six qutrits, 1/2/4 shared circuit layers, four propagation arms, GCN/GCN–TokenGT/TokenGT, softmax/tropical attention, and two fixed seeds. The independent verifier rehashed 432 epoch checkpoints and 725 forecast arrays. The score contains validation, stress, October test, CHF and November afternoon results. Full runner commands and split definitions are in the PhaseWeave checkout under `docs/BACKBONE_CLOCK_GRID.md`.

| Receipt | SHA-256 |
|---|---|
| Fit seal | `fdff3d2258594cb693361d0fccc3b481c30209f804b2ebfdc76a73c3c5b460e4` |
| Forecast seal | `2819bd936dc0ba58d3f7fa92885725a477943fe3528d79326d2bbf6decb626b9` |
| Aggregate scores | `55390f310bc847cc7d776f11e28ddfa39e42c20e0e3f5f74f0d744e230c3a9cc` |
| Independent score replay | `991f124b4f7f6f12281aca4401ae5d98dbef5fe3e0108b8b622bd93165d5d0cd` |
