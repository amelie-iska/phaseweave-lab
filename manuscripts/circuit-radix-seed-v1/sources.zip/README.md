# Circuit phase across training seeds

`compact.tex` is the research note. `extended.tex` includes the crossed-bootstrap derivation and setting-level persistence comparisons. Use the pinned `score.json` shipped in the source ZIP or the corresponding aggregate at `evaluations/circuit-radix-seed-replication-v1.json`. To regenerate tables and build without overwriting an earlier result, copy the six authored TeX files and `tables.py` to a fresh directory. From that directory, run the following.

```sh
python3 -B tables.py /path/to/score.json .
pdflatex -halt-on-error compact.tex
pdflatex -halt-on-error extended.tex
```
