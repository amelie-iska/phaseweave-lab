"""Render paper tables from the pinned public aggregate."""
from hashlib import sha256
import json
from pathlib import Path
import sys


SCORE_SHA = "60370c120508fb172f863842ad4acd40f752e27867b77402791d9dddc69ee4ef"
ROLES = ("october", "november")
RADICES = (2, 3, 5)
PHASES = ("entangling", "product")


def interval(bounds):
    lower, upper = bounds
    return f"$[{lower:+.6f},{upper:+.6f}]$"


def write_table(directory, name, rows):
    with (directory / name).open("x", encoding="utf-8") as stream:
        for row in rows:
            stream.write(" & ".join(map(str, row)) + r"\\" + "\n")


def main(receipt, directory):
    blob = receipt.read_bytes()
    if sha256(blob).hexdigest() != SCORE_SHA:
        raise ValueError("unexpected scoring receipt")
    data = json.loads(blob)
    phase_rows, seed_rows, baseline_rows = [], [], []
    for role in ROLES:
        panel = data["panels"][role]
        persistence = panel["cells"]["persistence"]["mae_bps"]
        for radix in RADICES:
            values = panel["phase_effects"][str(radix)]
            crossed = interval(values["crossed_interval_bps"])
            phase_rows.append((role.title(), radix, f'$ {values["mean_bps"]:+.6f} $',
                               interval(values["day_interval_bps"]), crossed,
                               values["seed_sign_counts"]["lower_error"]))
            seed_rows.append((role.title(), radix, f'{values["seed_sd_bps"]:.6f}',
                              interval(values["seed_interval_bps"]), crossed,
                              data["phase_sign_agreement_between_panels"][str(radix)]))
            for phase in PHASES:
                fits = [panel["cells"][f"tokengt-q{radix}-{phase}-{seed}"]["mae_bps"]
                        for seed in data["initialization_seeds"]]
                baseline_rows.append((radix, phase.title(), role.title(), f"{sum(fits)/len(fits):.6f}",
                                      f"{sum(value < persistence for value in fits)} / {len(fits)}"))
    write_table(directory, "phase-rows.tex", phase_rows)
    write_table(directory, "seed-rows.tex", seed_rows)
    write_table(directory, "persistence-rows.tex", baseline_rows)


if __name__ == "__main__":
    main(Path(sys.argv[1]), Path(sys.argv[2]))
