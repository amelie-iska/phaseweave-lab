# GRT markets and Graph protocol activity

The release includes source code, aggregate scores and public source checksums. The market forecasting task predicts the next bar's log return in basis points. The protocol and token-transfer models predict different forms of activity and use different units. Each fitted ridge model uses training-only feature scaling and a fixed L2 penalty of 1. There was no model selection on validation or test.

## Measured coverage

- The complete Binance monthly GRT/USDT spot archive at one-hour resolution contained 71 files from December 2020 through October 2026. Every archive matched its provider checksum. Six source rows had invalid close clocks and were excluded. There were 51,436 usable candles and 24 missing hourly slots in the covered range. Six contiguous closes within the same split were required for four lagged returns and the next return. On 739 October cases, the history-trained ridge MAE was 65.2920 log-bps, versus 65.2910 for zero return and 93.7673 for repeating the last return. [Binance archive documentation](https://github.com/binance/binance-public-data)
- August, September and October 2026 also yielded 2,208 hourly candles per instrument for GRT/USDT, BTC/USDT and ETH/USDT. Fits on August alone were scored on September and October. Protected EUR/USD historical midquotes and two October US equity trade samples (IVE, WDC) were fit separately with the same lag specification. Equity bins span five minutes. Zero return had the lowest October MAE on all six instruments. Volume, clocks and sampling differ; no cross-asset composite score was calculated. [HistData FAQ](https://www.histdata.com/f-a-q/) · [Kibot sample documentation](https://www.kibot.com/free-historical-intraday-data.html)
- The Graph’s Ethereum GRT ERC-20 contract supplied 1,200 archived transfer records via Blockscout. Excluding incomplete boundary blocks yielded 1,198 transfers across 809 active blocks, 581 addresses, and 799 directed pairs on October 21–22. The forecast target was log(1 + seconds until the next active block). The graph-feature ridge scored 0.8325 MAE on 157 chronological cases. A lag-only ridge scored 0.8304 and the training median scored 0.8630. Addresses can represent contracts and omnibus wallets. [The Graph token contract documentation](https://thegraph.com/docs/en/resources/tokenomics/) · [Blockscout API](https://github.com/blockscout/swaggers/tree/master/blockscout)
- On Arbitrum One, 12 million contiguous blocks emitted 5,568 events from The Graph’s L2GNS contract. The pinned protocol ABI mapped 5,565. All 725 distinct event-block hashes matched their canonical headers; those headers provided event times because all raw log clocks were zero. Complete three-hour UTC bins covered August 30 at 18:00 through October 5 at 18:00. Of 288 bins, 102 were empty. Predicting the next bin's event count on 54 test bins, graph-feature ridge MAE was 32.2410, lag-only ridge 27.2339 and training median 17.0370 events. Event counts include publication, version, signal and metadata changes. These observations concern one contract and chain. [The Graph L2GNS source address](https://thegraph.com/docs/en/subgraphs/existing-subgraphs/explorer/) · [Pinned GNS event ABI](https://github.com/graphprotocol/graph-network-subgraph/blob/fd5b03bdc6078ec978a30b1f11a9c7f45ee2e33c/abis/GNSStitched.json) · [Official Arbitrum read endpoint](https://docs.arbitrum.io/chain-info)

## Reproduce on the PhaseWeave checkout

Run from the repo root with its existing research Python, curl and NumPy. Set SCRIPTS to the directory containing these five Python files. Use a new output path. The multiasset fit reads the existing protected HistData and Kibot manifests in place.

```sh
OUT=artifacts/grt-source-audit-reproduction
python "$SCRIPTS/capture.py" "$OUT"
python "$SCRIPTS/fit.py" "$OUT" "$OUT/metrics.json"
python "$SCRIPTS/full_grt_checked.py" capture "$OUT/grtusdt-complete-hourly-v1" metrics.json
python "$SCRIPTS/gns.py" capture "$OUT/graph-network-gns"
python "$SCRIPTS/gns_clock.py" "$OUT/graph-network-gns" capture metrics.json
```

The release GNS entry point separates acquisition from scoring. It rejects a zero log clock. This corrects the original acquisition script, which also produced an invalid preliminary result before canonical-clock repair. The released measured GNS receipt is exclusively the verified-clock run. The two guard changes alter the release script's digest; numeric replays use the same estimator. Acquisition timestamps, live catalogue metadata and source payloads may change, so the release records input hashes. The market and transfer metrics and both clock-verified GNS fits reproduced byte-for-byte when replayed against the frozen sources and original scoring code.

The Graph’s hosted subgraph network requires an API key. Uniswap’s deployed subgraphs each cover a particular protocol and chain. The contract reads above came directly from the public chain RPC. No hosted subgraph queries, orders, account actions, or staked transactions were made. [The Graph query documentation](https://thegraph.com/docs/en/subgraphs/querying/introduction/) · [Uniswap subgraph coverage](https://developers.uniswap.org/docs/ecosystem/subgraphs/overview)

