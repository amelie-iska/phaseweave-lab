"""Bounded, keyless capture. Run from the PhaseWeave repo with a new output directory."""
import calendar
import csv
from datetime import datetime, timezone
from hashlib import sha256
import io
import json
from pathlib import Path
import sys
import time
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import zipfile

TOKEN = "0xc944e90c64b2c07662a292be6244bdf05cda44a7"
CHAIN = "https://eth.blockscout.com/api/v2/tokens/" + TOKEN + "/transfers"
BASE = "https://data.binance.vision/data/spot/monthly/klines"
PROTOCOL = {
    "digital": "All hourly candles 2026 Aug/train, Sep/validation, Oct/test for GRTUSDT BTCUSDT ETHUSDT. Same contiguous four return lags; target following one-hour log return (bps).",
    "foreign_exchange": "Same private EURUSD hourly midquote features/splits. Exclude discontinuities.",
    "equities": "Existing private IVE and WDC archive; last observed trade per five-minute bar. October 21–26 train, 27–28 validation, 29–30 test in US Eastern calendar, exclude discontinuities and overnight boundaries.",
    "chain": "Up to 24 keyless pages of 50 GRT ERC20 transfers preceding exclusive cursor (26250000,0). Exclude both boundary blocks. Model next active block interarrival in log1p seconds. Split complete active blocks chronologically floor(60%)/floor(80%); feature and target in same split. No assumption about end-user identities or swaps. No transaction submission.",
    "models": "Fit independently per series, standardized training-only ridge, lambda 1.0, unpenalized intercept. Compare zero return or train-median waiting time and last observed change or gap. Chain also compare matched lag-only ridge to extended current-edge-count, distinct endpoint, repeated directed edge fraction and amount features. Single frozen specification; no hyperparameter search or costs.",
}
def save(path, content):
    with path.open("xb") as stream:
        stream.write(content)

def packed(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n").encode()

def get(url):
    for attempt in range(3):
        try:
            req = Request(url, headers={"User-Agent":"PhaseWeave keyless reproducible research"})
            with urlopen(req, timeout=20) as reply:
                if reply.geturl() != url or reply.status != 200:
                    raise ValueError("unexpected redirect/status")
                data = reply.read(4_000_001)
                if len(data) > 4_000_000:
                    raise ValueError("archive cap exceeded")
                return data
        except OSError:
            if attempt == 2:
                raise
            time.sleep(2 + attempt)

def capture(out):
    out.mkdir(parents=False, exist_ok=False)
    save(out/"protocol.json", packed(PROTOCOL))
    records = []
    opened = datetime.now(timezone.utc).isoformat()
    for symbol in ("GRTUSDT","ETHUSDT","BTCUSDT"):
        for month in (8,9,10):
            name = f"{symbol}-1h-2026-{month:02d}.zip"
            url = f"{BASE}/{symbol}/1h/{name}"
            check = get(url + ".CHECKSUM")
            expected, base = check.decode().split()
            content = get(url)
            if base != name or sha256(content).hexdigest() != expected:
                raise ValueError("provider checksum mismatch")
            with zipfile.ZipFile(io.BytesIO(content)) as archive:
                if archive.namelist() != [name[:-3]+"csv"]:
                    raise ValueError("unexpected zip member")
                rows = list(csv.reader(io.TextIOWrapper(archive.open(archive.namelist()[0]))))
            first = int(datetime(2026,month,1,tzinfo=timezone.utc).timestamp())*1_000_000
            if len(rows) != calendar.monthrange(2026,month)[1]*24:
                raise ValueError("unexpected number of hourly records")
            for i,r in enumerate(rows):
                if len(r)!=12 or int(r[0])!=first+i*3_600_000_000 or int(r[6])-int(r[0])!=3_599_999_999:
                    raise ValueError("bad hourly timestamp")
                o,h,l,c,vol=map(float,r[1:6])
                if not (0 < l <= min(o,c) <= max(o,c) <= h and vol>=0 and int(r[8])>=0):
                    raise ValueError("invalid candle")
            save(out/name,content)
            save(out/(name+".CHECKSUM"),check)
            records.append({"file":name,"url":url,"rows":len(rows),"bytes":len(content),"sha256":expected})
    cursor = {"block_number":26250000,"index":0}
    seen = set()
    prior = (26250000,0)
    for i in range(24):
        url = CHAIN+"?"+urlencode(cursor)
        data = get(url)
        page = json.loads(data)
        rows=page["items"]
        if not rows: raise ValueError("missing historical page")
        for row in rows:
            key = (row["block_number"],row["log_index"])
            if key>=prior or key in seen or row["token"]["address_hash"].lower()!=TOKEN or row["token_type"]!="ERC-20" or row["total"]["decimals"]!="18":
                raise ValueError("unexpected ERC20 event ordering or identity")
            for who in ("from","to"):
                addr=row[who]["hash"]
                if len(addr)!=42 or not addr.startswith("0x"): raise ValueError("invalid transfer endpoint")
            if int(row["total"]["value"])<0: raise ValueError("invalid unsigned amount")
            seen.add(key)
            prior=key
        name=f"ethereum-grt-transfers-{i+1:03d}.json"
        save(out/name,data)
        records.append({"file":name,"url":url,"rows":len(rows),"bytes":len(data),"sha256":sha256(data).hexdigest()})
        cursor=page["next_page_params"]
        if cursor is None: break
        if set(cursor)!={"block_number","index"}: raise ValueError("unrecognized cursor")
    save(out/"source-manifest.json",packed({"sources":records,"opened_utc":opened,"completed_utc":datetime.now(timezone.utc).isoformat(),"protocol_sha256":sha256((out/"protocol.json").read_bytes()).hexdigest()}))
if __name__=="__main__":
    capture(Path(sys.argv[1]))

