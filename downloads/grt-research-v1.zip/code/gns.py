"""Read-only capture and chronological activity model for The Graph's Arbitrum L2GNS contract."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import hashlib
import numpy as np
from fit import packed, digest

RPC="https://arb1.arbitrum.io/rpc"
ADDRESS="0xec9a7fb6cbc2e41926127929c2dce6e9c5d33bec"
ABI="https://raw.githubusercontent.com/graphprotocol/graph-network-subgraph/fd5b03bdc6078ec978a30b1f11a9c7f45ee2e33c/abis/GNSStitched.json"
ABISHA="82ef0e6b37b2a5b416a558a4f801829176c0423c1db72b10ef930027e964b9a3"
START=500000000
STOP=512000000
HOP=1000000
BAR=10800
PROTO={"chain":42161,"contract":ADDRESS,"blocks_half_open":[START,STOP],"abi":ABI,"abi_sha256":ABISHA,"bin_seconds":BAR,"target":"count all raw L2GNS contract events in next fixed complete UTC three-hour bin, including zero counts","fit":"Fixed four lagged counts (oldest to latest), optionally add unique current indexed subgraphIDs, deployments, curators and signature count. All contiguous bins. Chronological 60/20/20; reset four-lag histories at split boundaries. Unweighted ridge lambda 1.0, standardized with training data only, nonnegative output clamp; unit MAE per future bin, compare last count and training median. No selection or trading evaluation."}
def save(p,d):
    with p.open("xb")as f:f.write(d)
def fetch(url,data=None):
    cmd=["curl","--silent","--show-error","--fail","--max-time","25","--retry","2"]
    if data is not None:cmd+=["-H","Content-Type: application/json","--data-binary","@-"]
    return subprocess.run(cmd+[url],input=data,check=True,stdout=subprocess.PIPE).stdout
def rpc(calls):
    allowed={"eth_chainId","web3_sha3","eth_getLogs","eth_getBlockByNumber"}
    if not all(k in allowed for k,_ in calls):raise ValueError("read-only RPC methods only")
    req=[{"jsonrpc":"2.0","method":k,"params":p,"id":i+1} for i,(k,p) in enumerate(calls)]
    data=json.loads(fetch(RPC,packed(req)))
    order={r["id"]:r for r in data}
    return [order[i+1]["result"] for i in range(len(req))]
def logs(a,b):
    return rpc([("eth_getLogs",[{"address":ADDRESS,"fromBlock":hex(a),"toBlock":hex(b-1)}])])[0]
def key(r):
    return (int(r["blockNumber"],16),int(r["logIndex"],16))
def capture(out):
    out.mkdir(exist_ok=False)
    save(out/"protocol.json",packed(PROTO))
    abi=fetch(ABI)
    if hashlib.sha256(abi).hexdigest()!=ABISHA:raise ValueError("invalid ABI")
    fields=[e for e in json.loads(abi) if e.get("type")=="event"]
    signatures=[e["name"]+"("+",".join(t["type"] for t in e["inputs"])+")" for e in fields]
    hashes=rpc([("eth_chainId",[]),("web3_sha3",["0x"])]+[("web3_sha3",["0x"+s.encode().hex()]) for s in signatures])
    if hashes[:2]!=["0xa4b1","0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470"]:raise ValueError("invalid chain/hash contract")
    lut=dict(zip(hashes[2:],fields))
    if lut["0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"]["name"]!="Transfer":raise ValueError("ERC signature check failed")
    save(out/"topics.json",packed(lut))
    headers=rpc([("eth_getBlockByNumber",[hex(b),False]) for b in (START,STOP-1)])
    header=[{k:h[k] for k in ("number","hash","timestamp")} for h in headers]
    save(out/"bounds.json",packed(header))
    for a in range(START,STOP,HOP):
        r=logs(a,a+HOP)
        if a==START:
            halves=logs(a,a+HOP//2)+logs(a+HOP//2,a+HOP)
            if r!=halves:raise ValueError("full and half range mismatch")
        if any(not a<=key(e)[0]<a+HOP or e["address"].lower()!=ADDRESS or e["removed"] for e in r):raise ValueError("invalid event range/emitter")
        if [key(e) for e in r]!=sorted({key(e) for e in r}):raise ValueError("unordered or duplicate logs")
        save(out/f"logs-{a}.json",packed(r))
def score(out):
    lut=json.loads((out/"topics.json").read_text()); bounds=json.loads((out/"bounds.json").read_text())
    first=(int(bounds[0]["timestamp"],16)//BAR+1)*BAR; end=int(bounds[1]["timestamp"],16)//BAR*BAR
    bins=defaultdict(list);event_names=Counter();unmapped=Counter();count=0; decoded=0
    for path in sorted(out.glob("logs-*.json")):
        for r in json.loads(path.read_text()):
            count+=1;t=int(r["blockTimestamp"],16);top=r["topics"];e=lut.get(top[0])
            if t<=0: raise ValueError("zero GNS log clock; use gns_clock.py to verify canonical headers")
            if e is None:
                name="unmapped";fields={};unmapped[top[0]]+=1
            else:
                decoded+=1;name=e["name"]; ix=[f["name"] for f in e["inputs"] if f["indexed"]]
                if len(ix)!=len(top)-1:raise ValueError("indexed ABI layout differs")
                fields=dict(zip(ix,top[1:]))
            event_names[name]+=1
            if first<=t<end:bins[t//BAR*BAR].append((top[0],fields))
    features=[]
    for k in range(first,end,BAR):
        events=bins[k]
        v=[len({f[key] for _,f in events if key in f}) for key in ("subgraphID","subgraphDeploymentID","curator")]
        features.append([len(events),*v,len({x for x,_ in events})])
    arr=np.array(features,dtype=float);n=len(arr); cuts=[0,n*3//5,n*4//5,n]
    splits=[]
    for a,b in zip(cuts,cuts[1:]):
        cases=[([*arr[i-3:i+1,0],*arr[i,1:]],arr[i+1,0]) for i in range(a+3,b-1)]
        splits.append((np.array([c[0] for c in cases]),np.array([c[1] for c in cases])))
    def utc(t):return datetime.fromtimestamp(t,timezone.utc).isoformat()
    receipt={"protocol":PROTO,"source_code_sha256":digest(Path(__file__)),"input_hashes":{p.name:digest(p) for p in sorted(out.glob("*.json")) if p.name not in ("metrics.json","replay.json")},"raw_events":count,"mapped_events":decoded,"unmapped_topic_counts":dict(unmapped),"event_counts":dict(event_names),"usable_events":int(arr[:,0].sum()),"complete_bins":n,"empty_bins":int((arr[:,0]==0).sum()),"complete_utc_window_half_open":[utc(first),utc(end)],"splits":{},"fits":{}}
    for ix,(a,b) in enumerate(zip(cuts,cuts[1:])):
        receipt["splits"][("train","validation","test")[ix]]={"n":len(splits[ix][1]),"complete_bin_bounds_utc_half_open":[utc(first+a*BAR),utc(first+b*BAR)]}
    for name,size in (("event_count_lags",4),("event_count_lags_plus_graph",8)):
        X,y=splits[0];X=X[:,:size];m=X.mean(0);s=X.std(0);s[s==0]=1;Z=(X-m)/s;bias=y.mean()
        w=np.linalg.solve(Z.T@Z+np.eye(size),Z.T@(y-bias))
        scores={}
        for split,(xx,yy) in zip(("train","validation","test"),splits):
            pred=np.maximum(0,bias+(xx[:,:size]-m)/s@w)
            scores[split]={k:float(np.abs(yy-p).mean()) for k,p in (("ridge",pred),("last_count",xx[:,3]),("train_median",np.median(y)))}
        receipt["fits"][name]={"scores_mae_events_per_bin":scores,"standardized_coefficients":w.tolist(),"train_means":m.tolist(),"train_scales":s.tolist(),"intercept":float(bias)}
    return receipt
if __name__=="__main__":
    out=Path(sys.argv[2])
    if sys.argv[1]=="capture":
        capture(out)
    elif sys.argv[1]=="replay":
        save(out/sys.argv[3],packed(score(out)))
    else:
        raise ValueError("choose capture or replay")

