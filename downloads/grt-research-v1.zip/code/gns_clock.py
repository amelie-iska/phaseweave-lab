"""Repair zero log clocks using canonical Arbitrum block headers before chronological scoring."""
from pathlib import Path
import sys
import time
import json
import gns
from fit import packed,digest

def recover(raw,dest):
    dest.mkdir(exist_ok=False)
    for name in ("protocol.json","bounds.json","topics.json"):
        gns.save(dest/name,(raw/name).read_bytes())
    maps={}
    payloads={p:json.loads(p.read_text()) for p in sorted(raw.glob("logs-*.json"))}
    for rows in payloads.values():
        for r in rows:
            if maps.setdefault(r["blockNumber"],r["blockHash"])!=r["blockHash"]:raise ValueError("conflicting block hash")
    ids=sorted(maps,key=lambda b:int(b,16)); verified={}
    for i in range(0,len(ids),8):
        chunk=ids[i:i+8]
        batch=gns.rpc([("eth_getBlockByNumber",[b,False]) for b in chunk])
        for b,h in zip(chunk,batch):
            if h["number"]!=b or h["hash"]!=maps[b] or int(h["timestamp"],16)<=0:raise ValueError("block hash/clock mismatch")
            verified[b]={k:h[k] for k in ("number","hash","timestamp")}
        time.sleep(0.5)
    times=[int(verified[k]["timestamp"],16) for k in ids]
    if times!=sorted(times):raise ValueError("non-monotone header clocks")
    gns.save(dest/"canonical-headers.json",packed(verified))
    for path,rows in payloads.items():
        for r in rows:r["blockTimestamp"]=verified[r["blockNumber"]]["timestamp"]
        gns.save(dest/path.name,packed(rows))
    gns.save(dest/"clock-provenance.json",packed({"source":gns.RPC,"method":"eth_getBlockByNumber","historical_raw_logs_sha256":{p.name:digest(p) for p in payloads},"unique_block_headers":len(verified),"lookup_code_sha256":digest(Path(__file__)),"reason":"Every log provided zero blockTimestamp; protocol requires canonical UTC. Original logs preserved."}))
def verify(dest,name):
    score=gns.score(dest)
    if score["usable_events"]<score["raw_events"]*0.9 or score["usable_events"]>score["raw_events"] or score["empty_bins"]>=score["complete_bins"]:raise ValueError("invalid clock coverage")
    gns.save(dest/name,packed(score))
if __name__=="__main__":
    raw=Path(sys.argv[1]); dest=raw/"verified-clock-v1"
    if sys.argv[2]=="capture":recover(raw,dest)
    verify(dest,sys.argv[3])

