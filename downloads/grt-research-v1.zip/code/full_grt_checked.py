"""All monthly GRTUSDT hourly files in the official catalogue through 2026-10; fixed walk-forward split."""
import csv
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import io
import json
from pathlib import Path
import re
import sys
import math
import xml.etree.ElementTree as ET
import zipfile
from capture import get,save,packed,BASE
from fit import digest,summary
LIST="https://s3-ap-northeast-1.amazonaws.com/data.binance.vision?list-type=2&prefix=data/spot/monthly/klines/GRTUSDT/1h/"
def collect(out):
    out.mkdir(exist_ok=False)
    save(out/"protocol.json",packed({"scope":"Every official Binance spot GRTUSDT one-hour monthly kline ZIP in public S3 prefix with month <= 2026-10. Use all eligible consecutive bars. Train through 2026-08, September validation, October test; same frozen four-return ridge and controls as short sample. August–October overlap is intentional; same October labels. No parameter selection, target next hourly close return in log-bps."}))
    raw=get(LIST);p=ET.fromstring(raw);tag="{http://s3.amazonaws.com/doc/2006-03-01/}"
    if p.findtext(tag+"IsTruncated")!="false":raise ValueError("uncaptured pages")
    save(out/"catalogue.xml",raw)
    names=sorted(e.findtext(tag+"Key").split("/")[-1] for e in p.findall(tag+"Contents") if e.findtext(tag+"Key").endswith(".zip"))
    names=[n for n in names if re.fullmatch(r"GRTUSDT-1h-\d{4}-\d{2}\.zip",n) and n<="GRTUSDT-1h-2026-10.zip"]
    def one(name):
        base=f"{BASE}/GRTUSDT/1h/{name}"
        existing=out.parent/name
        if existing.exists():
            content=existing.read_bytes();check=(out.parent/(name+".CHECKSUM")).read_bytes(); rel="../"+name
        else:
            content=get(base);check=get(base+".CHECKSUM");rel=name
        import hashlib
        expected,provider_name=check.decode().split()
        if provider_name!=name or expected!=hashlib.sha256(content).hexdigest():raise ValueError("checksum mismatch "+name)
        if not existing.exists():
            save(out/name,content);save(out/(name+".CHECKSUM"),check)
        return {"file":rel,"url":base,"checksum_url":base+".CHECKSUM","sha256":expected,"bytes":len(content)}
    with ThreadPoolExecutor(max_workers=3) as pool: info=list(pool.map(one,names))
    save(out/"archives.json",packed(info))
def score(out):
    v={};archive_rows={};gaps=[]; malformed={}
    for r in json.loads((out/"archives.json").read_text()):
        p=out/r["file"];scale=1_000_000 if p.name[11:18]>="2025-01" else 1000
        if digest(p)!=r["sha256"]:raise ValueError("checksum changed")
        n=0
        with zipfile.ZipFile(p) as z:
            if z.namelist()!=[p.stem+".csv"]:raise ValueError("bad zip schema")
            for x in csv.reader(io.TextIOWrapper(z.open(z.namelist()[0]))):
                end=int(x[6]);start=int(x[0]);ts=start//scale
                if ts in v or start%scale!=0 or ts%3600!=0 or len(x)!=12:raise ValueError("invalid or duplicate candle")
                if end-start!=3600*scale-1:
                    malformed[p.name]=malformed.get(p.name,0)+1
                    continue
                if datetime.fromtimestamp(ts,timezone.utc).strftime("%Y-%m")!=p.name[11:18]:raise ValueError("wrong month or timestamp unit")
                o,h,l,c,vol=map(float,x[1:6])
                if not 0<l<=min(o,c)<=max(o,c)<=h or vol<0:raise ValueError("invalid price")
                v[ts]=c;n+=1
        archive_rows[p.name]=n
    split=lambda t: 0 if t<1788220800 else 1 if t<1790812800 else 2
    # Audit constants against the UTC calendar to protect the split.
    for code,num in (("2026-09-01",1788220800),("2026-10-01",1790812800)):
        if int(datetime.fromisoformat(code).replace(tzinfo=timezone.utc).timestamp())!=num:raise ValueError("wrong split")
    periods=[[],[],[]]
    keys=sorted(v)
    for a,b in zip(keys,keys[1:]):
        if b-a!=3600:gaps.append((a,b))
    for t in keys:
        ticks=[t-i*3600 for i in range(5,-1,-1)]
        if not all(k in v for k in ticks) or split(ticks[0])!=split(t):continue
        returns=[1e4*math.log(v[b]/v[a]) for a,b in zip(ticks,ticks[1:])]
        periods[split(t)].append((t,t+3600,returns[:-1],returns[-1]))
    return {"code_sha256":digest(Path(__file__)),"archives_sha256":digest(out/"archives.json"),"catalogue_sha256":digest(out/"catalogue.xml"),"protocol_sha256":digest(out/"protocol.json"),"excluded_invalid_close_timestamps":malformed,"monthly_files":len(archive_rows),"archive_rows":archive_rows,"hourly_bars":len(v),"first_open_utc":datetime.fromtimestamp(keys[0],timezone.utc).isoformat(),"last_exclusive_utc":datetime.fromtimestamp(keys[-1]+3600,timezone.utc).isoformat(),"internal_gap_count":len(gaps),"missing_hourly_bars_inside_range":sum((b-a)//3600-1 for a,b in gaps),"fit":summary(periods,"full_archive_hourly_close_return","zero_return")}
if __name__=="__main__":
    out=Path(sys.argv[2])
    if sys.argv[1]=="capture":collect(out)
    save(out/sys.argv[3],packed(score(out)))

