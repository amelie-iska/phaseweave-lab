"""Fit chronological per-instrument pilots using only the named public/protected source manifests."""
from collections import defaultdict
import csv
from datetime import datetime, timezone
import gzip
from hashlib import sha256
import io
import json
import math
from pathlib import Path
import sys
from zoneinfo import ZoneInfo
import zipfile
import numpy as np

ROOT=Path.cwd()
sys.path.insert(0,str(ROOT/"research"))
from histdata_probe import quote_rows
from audit_kibot_equity_sample import parse as equity_parse

SPLITS=("train","validation","test")
def digest(path):
    return sha256(path.read_bytes()).hexdigest()
def load(path):
    return json.loads(path.read_bytes())
def packed(value):
    return (json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+"\n").encode()
def align(path,expected):
    if digest(path)!=expected: raise ValueError("source digest mismatch "+path.name)
def split_bar(ts,bar_seconds):
    date=datetime.fromtimestamp(ts,timezone.utc)
    if bar_seconds==300:
        day=date.astimezone(ZoneInfo("America/New_York")).day
        if date.month!=10 or not 21<=day<=30: return None
        return 0 if day<=26 else 1 if day<=28 else 2
    return {8:0,9:1,10:2}.get(date.month) if date.year==2026 else None
def returns_rows(prices,seconds):
    rows=[[],[],[]]
    for last in sorted(prices):
        ticks=[last-i*seconds for i in range(5,-1,-1)]
        parts={split_bar(t,seconds) for t in ticks}
        if len(parts)!=1 or None in parts or not all(t in prices for t in ticks): continue
        returns=[1e4*math.log(prices[b]/prices[a]) for a,b in zip(ticks,ticks[1:])]
        rows[parts.pop()].append((ticks[-2]+seconds,ticks[-1]+seconds,returns[:-1],returns[-1]))
    return rows
def summary(rows,model_kind,control):
    if min(len(s) for s in rows)<8: raise ValueError("insufficient split support")
    groups=[(np.array([r[2] for r in s]),np.array([r[3] for r in s])) for s in rows]
    a,y=groups[0]
    mu=a.mean(0); sd=a.std(0); sd[sd<1e-12]=1
    z=(a-mu)/sd
    intercept=float(y.mean())
    coef=np.linalg.solve(z.T@z+np.eye(z.shape[1]),z.T@(y-intercept))
    const=0 if control=="zero_return" else float(np.median(y))
    metrics={}
    for s,(x,target),name in zip(rows,groups,SPLITS):
        pred=intercept+((x-mu)/sd)@coef
        candidates={"ridge":pred,control:np.full_like(target,const),"last_observed":x[:,3]}
        results={k:float(np.mean(np.abs(target-v))) for k,v in candidates.items()}
        metrics[name]={"n":len(target),"mae":results,"first_feature_end_utc":datetime.fromtimestamp(s[0][0],timezone.utc).isoformat(),"last_target_end_utc":datetime.fromtimestamp(s[-1][1],timezone.utc).isoformat()}
    if not all(rows[i][-1][1]<rows[i+1][0][0] for i in (0,1)):
        raise ValueError("non-disjoint split dates")
    return {"model":model_kind,"l2":1.0,"fits":1,"feature_means":mu.tolist(),"feature_scales":sd.tolist(),"intercept":intercept,"standardized_coefficients":coef.tolist(),"scores":metrics}
def chain(out,files):
    byblock=defaultdict(list)
    seen=set()
    for f in files:
        for r in load(out/f)["items"]:
            k=(r["block_number"],r["log_index"])
            if k in seen: raise ValueError("duplicate transfer")
            seen.add(k)
            byblock[k[0]].append(r)
    nums=sorted(byblock)[1:-1]
    edges=set(); endpoints=set()
    stats=[]; times=[]
    prior=0
    for n in nums:
        rows=byblock[n]
        if len({r["block_hash"] for r in rows})!=1 or len({r["timestamp"] for r in rows})!=1:
            raise ValueError("block mismatch")
        t=int(datetime.fromisoformat(rows[0]["timestamp"].replace("Z","+00:00")).timestamp())
        if t<=prior: raise ValueError("non-monotone blocks")
        prior=t
        pairs=[(r["from"]["hash"].lower(),r["to"]["hash"].lower()) for r in rows]
        unique={who for p in pairs for who in p}
        # Count repeats against completed strictly earlier blocks only.
        frac=sum(p in edges for p in pairs)/len(pairs)
        amount=sum(int(r["total"]["value"]) for r in rows)/1e18
        stats.append([math.log1p(len(rows)),math.log1p(len(unique)),frac,math.log1p(amount)])
        times.append(t)
        edges.update(pairs);endpoints.update(unique)
    cuts=(0,len(times)*3//5,len(times)*4//5,len(times))
    rows=[[],[],[]]
    for split,(start,end) in enumerate(zip(cuts,cuts[1:])):
        for i in range(start+4,end-1):
            gaps=[math.log1p(times[k]-times[k-1]) for k in range(i-3,i+1)]
            target=math.log1p(times[i+1]-times[i])
            rows[split].append((times[i],times[i+1],gaps+stats[i],target))
    bare=[[(t,h,x[:4],y) for t,h,x,y in s] for s in rows]
    return {"captured_transfers":len(seen),"complete_blocks":len(nums),"complete_block_transfers":sum(len(byblock[b]) for b in nums),"distinct_observed_accounts":len(endpoints),"distinct_directed_pairs":len(edges),"excluded_boundary_blocks":2,"block_range":[nums[0],nums[-1]],"utc_range":[datetime.fromtimestamp(t,timezone.utc).isoformat() for t in (times[0],times[-1])],"target":"log(1 + seconds to next block containing a GRT transfer)","features":"four prior log gaps, current log1p(event count, distinct endpoint count), prior-observed directed pair fraction, current log1p(total GRT transferred)","graph_ridge":summary(rows,"lag_and_transfer_graph","train_median"),"lag_ridge":summary(bare,"lag_only","train_median")}
def run(out):
    source=load(out/"source-manifest.json")
    align(out/"protocol.json",source["protocol_sha256"])
    bars=defaultdict(dict)
    chainfiles=[]
    for r in source["sources"]:
        path=out/r["file"];align(path,r["sha256"])
        if path.suffix==".json":
            chainfiles.append(path.name);continue
        with zipfile.ZipFile(path) as archive:
            with archive.open(archive.namelist()[0]) as f:
                for x in csv.reader(io.TextIOWrapper(f)):
                    bars[path.name.split("-")[0]][int(x[0])//1_000_000]=float(x[4])
    doc={"protocol_sha256":source["protocol_sha256"],"source_manifest_sha256":digest(out/"source-manifest.json"),"code_sha256":digest(Path(__file__)),"private_manifests":{},"source_counts":{},"series":{}}
    for k,v in sorted(bars.items()):
        doc["source_counts"][k]=len(v)
        doc["series"][k]=summary(returns_rows(v,3600),"hourly_close_return","zero_return")
    fx=ROOT/"data/histdata-pilot"
    fxmanifest=load(fx/"manifest.json")
    doc["private_manifests"]["histdata"]=digest(fx/"manifest.json")
    v={};n=0
    for a in fxmanifest["archives"]:
        if a["pair"]!="EURUSD":continue
        path=fx/Path(a["file"]).name;align(path,a["sha256"])
        month=datetime.strptime(path.stem.split("-",1)[1],"%Y-%m")
        for _,stamp,bid,ask in quote_rows(path,"EURUSD",month):
            t=int(stamp.timestamp());v[t//3600*3600]=(bid+ask)/2;n+=1
    doc["source_counts"]["EURUSD"]={"raw_ticks":n,"observed_hourly_bars":len(v)}
    doc["series"]["EURUSD"]=summary(returns_rows(v,3600),"hourly_midquote_return","zero_return")
    eq=ROOT/"data/kibot-equity-validation-v1"
    doc["private_manifests"]["kibot"]=digest(eq/"manifest.json")
    for rec in load(eq/"manifest.json")["captures"]:
        path=eq/rec["file"];align(path,rec["gzip_sha256"])
        v={}; n=0
        with gzip.open(path,"rb") as stream:
            for line in stream:
                stamp,_=equity_parse(line)
                price=float(line.split(b",")[2]);t=int(stamp.timestamp());n+=1
                v[t//300*300]=price
        doc["source_counts"][rec["symbol"]]={"raw_ticks":n,"observed_5min_bars":len(v)}
        doc["series"][rec["symbol"]]=summary(returns_rows(v,300),"five_minute_last_trade_return","zero_return")
    doc["chain"]=chain(out,chainfiles)
    return doc
if __name__=="__main__":
    with Path(sys.argv[2]).open("xb") as stream:stream.write(packed(run(Path(sys.argv[1]))))

