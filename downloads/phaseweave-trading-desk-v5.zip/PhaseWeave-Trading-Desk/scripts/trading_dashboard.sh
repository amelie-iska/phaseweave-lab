#!/bin/sh
set -eu
root=$(CDPATH='' cd -- "$(dirname "$0")/.." && pwd)
exec "${PHASEWEAVE_PYTHON:-python3}" "$root/research/trading_desk.py" "$@"
