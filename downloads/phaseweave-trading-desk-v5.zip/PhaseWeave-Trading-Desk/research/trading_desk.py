"""Loopback PhaseWeave dashboard with public market data and paper execution."""

from argparse import ArgumentParser
from collections import Counter, deque
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from functools import partial
from http import HTTPStatus
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
from threading import Event, RLock, Thread
import time
from urllib.error import URLError
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, urlopen

GATE = "https://api.gateio.ws/api/v4/spot/order_book"
ASSETS = ("ETH", "XRP")
BP = Decimal(10000)
LOG_ROWS = 180
POLL_SECONDS = 2
# Fixed allowance for receipt-clock agreement; larger venue leads fail closed.
FUTURE_CLOCK_TOLERANCE_MS = 250
DEFAULTS = {"asset":"ETH","notional":100.,"fee_bps":10.,"edge_bps":1.,"age_ms":1500,
            "max_skew_ms":750,"leg_delay_ms":1500,"loss_cap":5.}


def now_ms():
    return time.time_ns() // 1_000_000


def iso(ms):
    return datetime.fromtimestamp(ms/1000,tz=timezone.utc).isoformat(timespec="milliseconds")


def dec(value):
    number = Decimal(str(value))
    if not number.is_finite():
        raise ValueError("numeric value must be finite")
    return number


def capital_config(raw):
    bounds = {"notional":(1,10000),"fee_bps":(0,100),"edge_bps":(0,500),"age_ms":(100,12000),
              "max_skew_ms":(50,5000),"leg_delay_ms":(100,15000),"loss_cap":(.01,10000)}
    if set(raw)-set(DEFAULTS):
        raise ValueError("unexpected strategy setting")
    config = dict(DEFAULTS,**raw)
    if config["asset"] not in ASSETS:
        raise ValueError("choose ETH or XRP")
    for key,(minimum,maximum) in bounds.items():
        value = float(dec(config[key]))
        if not minimum <= value <= maximum:
            raise ValueError(f"{key} outside [{minimum}, {maximum}]")
        config[key] = int(value) if key.endswith("_ms") else value
    return config


def legs(asset):
    return {
        f"USDT → BTC → {asset} → USDT": (("BTC_USDT",True),(f"{asset}_BTC",True),(f"{asset}_USDT",False)),
        f"USDT → {asset} → BTC → USDT": ((f"{asset}_USDT",True),(f"{asset}_BTC",False),("BTC_USDT",False)),
    }


def quotes(pairs):
    with ThreadPoolExecutor(max_workers=len(pairs)) as workers:
        return dict(zip(pairs,workers.map(fetch_book,pairs),strict=True))


def fetch_book(pair):
    query=urlencode({"currency_pair":pair,"limit":10,"with_id":"true"})
    request=Request(f"{GATE}?{query}",headers={"User-Agent":"PhaseWeave-local/1","Accept":"application/json"})
    start=now_ms()
    with urlopen(request,timeout=4) as response:
        raw=json.loads(response.read(128_000))
    return normalize_book(raw,start,now_ms())


def normalize_book(raw,start,received):
    update=int(raw["update"])
    exchange=int(raw["current"])
    if update>exchange or update<=0 or exchange<=0 or received<start:
        raise ValueError("inconsistent venue or local timestamps")
    parsed={}
    for side in ("bids","asks"):
        levels=tuple((dec(p),dec(q)) for p,q in raw[side])
        if not (1<=len(levels)<=10) or any(p<=0 or q<=0 for p,q in levels):
            raise ValueError("invalid order book depth")
        prices=[price for price,_ in levels]
        if prices!=sorted(set(prices),reverse=side=="bids"):
            raise ValueError("price levels are unsorted or repeated")
        parsed[side]=levels
    if parsed["bids"][0][0]>=parsed["asks"][0][0]:
        raise ValueError("crossed snapshot")
    sequence = int(raw["id"])
    if sequence <= 0:
        raise ValueError("invalid venue book ID")
    return {"id":sequence,"update":update,"venue_ms":exchange,"received_ms":received,
            "rtt_ms":received-start,**parsed}


def book_age(book,stamp):
    transport_age = book["venue_ms"]-book["update"] + stamp-book["received_ms"]+book["rtt_ms"]
    return max(transport_age, stamp-book["update"])


def quote_rejection(book, stamp, max_age_ms, watermark):
    if book["received_ms"] > stamp or book["venue_ms"] > book["received_ms"] + FUTURE_CLOCK_TOLERANCE_MS:
        return "future_clock"
    if not 0 <= book_age(book,stamp) <= max_age_ms:
        return "stale"
    if watermark is not None:
        last_id,last_update=watermark
        if book["id"] <= last_id or book["update"] < last_update:
            return "replayed_sequence"
    return None


def execute_leg(book,buy,amount,fee):
    pending,proceeds=amount,Decimal(0)
    for levels,(price,size) in enumerate(book["asks" if buy else "bids"],1):
        taken=min(pending,price*size if buy else size)
        proceeds += taken/price if buy else taken*price
        pending -= taken
        if not pending:
            return proceeds*(1-fee/BP),levels
    return None,None


def estimate(route,books,amount,fee):
    for pair,buy in route:
        amount,_=execute_leg(books[pair],buy,amount,fee)
        if amount is None:
            return None
    return amount


def margin(output,initial):
    return float(BP*(output/initial).ln()) if output is not None else None


class Desk:
    def __init__(self):
        self.lock=RLock()
        self.config=dict(DEFAULTS)
        self.connected=self.armed=False
        self.message="Live quotes paused"
        self.version=0
        self.frames=deque(maxlen=LOG_ROWS)
        self.events=deque(maxlen=360)
        self.counts=Counter()
        self.pending=None
        self.ended=None
        self.pnl=Decimal(0)
        self.peak=Decimal(0)
        self.max_drawdown=Decimal(0)
        self.last_candidates={}
        self.last_books={}
        self.watermarks={}

    def emit(self,kind,stamp,**fields):
        self.counts[kind]+=1
        self.events.append({"type":kind,"utc":iso(stamp),**fields})

    def setup(self,action,data):
        with self.lock:
            if action=="connect":
                self.connected=True
                self.message="Waiting for the first book snapshot"
            elif action=="disconnect":
                if self.pending:
                    raise ValueError("finish or mark the active paper cycle before disconnecting")
                self.connected=self.armed=False
                self.message="Live quotes paused"
                self.version+=1
            elif action=="configure":
                if self.armed or self.pending:
                    raise ValueError("pause new cycles and finish the current one before changing settings")
                new=capital_config(data)
                if new["asset"]!=self.config["asset"]:
                    self.frames.clear()
                    self.last_books={}
                    self.last_candidates={}
                    self.version+=1
                self.config=new
            elif action=="start":
                if not self.connected or self.ended or -self.pnl>=dec(self.config["loss_cap"]):
                    raise ValueError("connect the feed and resolve any session stop before arming paper cycles")
                self.armed=True
                self.emit("armed",now_ms())
            elif action=="pause":
                self.armed=False
                self.emit("paused",now_ms())
            elif action=="mark-stranded":
                if not self.pending:
                    raise ValueError("no active paper cycle")
                self.stop_cycle("operator marked inventory",now_ms())
            else:
                raise ValueError("unknown operation")

    def stop_cycle(self,reason,stamp):
        cycle=self.pending
        self.pending=None
        self.armed=False
        if cycle["leg"]:
            self.ended={"reason":reason,"stranded_asset":cycle["asset"],"amount":float(cycle["amount"])}
        self.emit("cycle_failed",stamp,route=cycle["name"],reason=reason,inventory=self.ended)

    def snapshot(self,books,stamp,version):
        with self.lock:
            if version!=self.version or not self.connected:
                return
            self.message="Public Gate spot depth"
            self.counts["snapshots"]+=1
            receipts=[b["received_ms"] for b in books.values()]
            skew=max(receipts)-min(receipts)
            reasons={pair:quote_rejection(b,stamp,self.config["age_ms"],self.watermarks.get(pair))
                     for pair,b in books.items()}
            admissible=skew<=self.config["max_skew_ms"] and not any(reasons.values())
            if skew<=self.config["max_skew_ms"]:
                # Validate each market independently; a discarded book can never advance its watermark.
                for pair,b in books.items():
                    if reasons[pair] is None:
                        self.watermarks[pair]=(b["id"],b["update"])
            if not admissible:
                self.counts["rejected_snapshots"]+=1
                for reason in set(reasons.values())-{None}:
                    self.counts["rejected_"+reason]+=1
                if skew>self.config["max_skew_ms"]:
                    self.counts["rejected_receipt_skew"]+=1
            self.last_books={pair:{
                "id":book["id"],"age_ms":book_age(book,stamp),"rtt_ms":book["rtt_ms"],
                "bid":float(book["bids"][0][0]),"ask":float(book["asks"][0][0]),
                "exchange_update_utc":iso(book["update"]),"rejection":reasons[pair]} for pair,book in books.items()}
            initial=dec(self.config["notional"])
            fee=dec(self.config["fee_bps"])
            roster=legs(self.config["asset"])
            self.last_candidates = {name:margin(estimate(path,books,initial,fee),initial) if admissible else None
                                    for name,path in roster.items()}
            self.store_frame(books,stamp,skew)
            if self.pending:
                self.walk_cycle(books,stamp,admissible,fee)
            elif self.armed:
                ranked=[(bps,name) for name,bps in self.last_candidates.items() if bps is not None]
                if not ranked or max(ranked)[0]<self.config["edge_bps"]:
                    self.counts["abstained"]+=1
                    return
                bps,name=max(ranked)
                self.pending={"name":name,"path":roster[name],"leg":0,"due_ms":stamp+self.config["leg_delay_ms"],
                              "deadline_ms":stamp+max(15000,3*self.config["leg_delay_ms"]),
                              "last_snapshot_ms":stamp,"initial":initial,"amount":initial,"asset":"USDT"}
                self.emit("cycle_proposed",stamp,route=name,indicative_bps=bps,notional=float(initial))

    def walk_cycle(self,books,stamp,admissible,fee):
        cycle=self.pending
        if stamp<=cycle["last_snapshot_ms"] or stamp<cycle["due_ms"]:
            return
        if stamp>cycle["deadline_ms"]:
            self.stop_cycle("book refresh timed out",stamp)
            return
        pair,buy=cycle["path"][cycle["leg"]]
        book=books[pair]
        if not admissible or book["received_ms"]<=cycle["last_snapshot_ms"]:
            self.counts["stale_arrivals"]+=1
            return
        proceeds,levels=execute_leg(book,buy,cycle["amount"],fee)
        if proceeds is None:
            self.stop_cycle("insufficient displayed depth",stamp)
            return
        cycle["leg"]+=1
        cycle["last_snapshot_ms"]=stamp
        cycle["due_ms"]=stamp+self.config["leg_delay_ms"]
        cycle["deadline_ms"]=stamp+max(15000,3*self.config["leg_delay_ms"])
        cycle["amount"]=proceeds
        cycle["asset"]=pair.split("_")[0 if buy else 1]
        self.emit("paper_leg",stamp,route=cycle["name"],leg=cycle["leg"],pair=pair,
                  book_id=book["id"],book_age_ms=book_age(book,stamp),levels=levels,
                  received=float(proceeds),asset=cycle["asset"])
        if cycle["leg"]==len(cycle["path"]):
            value=proceeds-cycle["initial"]
            self.pnl+=value
            self.peak=max(self.peak,self.pnl)
            self.max_drawdown=max(self.max_drawdown,self.peak-self.pnl)
            self.emit("cycle_closed",stamp,route=cycle["name"],pnl_usdt=float(value),
                      margin_bps=margin(proceeds,cycle["initial"]))
            self.pending=None
            if -self.pnl>=dec(self.config["loss_cap"]):
                self.armed=False
                self.emit("loss_limit",stamp,session_pnl_usdt=float(self.pnl))

    def store_frame(self,books,stamp,skew):
        depth={}
        btc=books["BTC_USDT"]
        btc_mid=(btc["bids"][0][0]+btc["asks"][0][0])/2
        for pair,book in books.items():
            top={side:book[side][0][0] for side in ("bids","asks")}
            mid=(top["bids"]+top["asks"])/2
            quote_to_usdt=btc_mid if pair.endswith("_BTC") else Decimal(1)
            depth[pair]={side:[[float(BP*(price/mid).ln()),float(price*qty*quote_to_usdt)]
                               for price,qty in book[side]] for side in top}
        self.frames.append({"utc":iso(stamp),"depth":depth,"skew_ms":skew,
                            "margins_bps":dict(self.last_candidates)})

    def fail_sample(self,stamp,version):
        with self.lock:
            if version!=self.version or not self.connected:
                return
            self.message="Public order book was unavailable"
            self.counts["feed_errors"]+=1
            self.last_books={}
            self.last_candidates={}
            if self.pending and stamp>self.pending["deadline_ms"]:
                self.stop_cycle("feed unavailable at paper leg deadline",stamp)

    def reader(self,stop):
        while not stop.is_set():
            with self.lock:
                asset,version,connected=self.config["asset"],self.version,self.connected
            if connected:
                try:
                    books=quotes(("BTC_USDT",f"{asset}_BTC",f"{asset}_USDT"))
                    self.snapshot(books,now_ms(),version)
                except (OSError,ValueError,KeyError,TypeError,InvalidOperation,URLError):
                    self.fail_sample(now_ms(),version)
            stop.wait(POLL_SECONDS)

    def status(self):
        with self.lock:
            latest=self.frames[-1] if self.frames else None
            pending=self.pending
            return {"mode":"paper","feed":self.message,"connected":self.connected,"armed":self.armed,
                    "config":dict(self.config),"counts":dict(self.counts),"pnl_usdt":float(self.pnl),
                    "max_drawdown_usdt":float(self.max_drawdown),"ended":self.ended,
                    "active":{"route":pending["name"],"legs":pending["leg"],"asset":pending["asset"],
                              "amount":float(pending["amount"])} if pending else None,
                    "last_capture_utc":latest["utc"] if latest else None,"candidate_bps":dict(self.last_candidates),
                    "books":dict(self.last_books),"frames":list(self.frames),"events":list(reversed(self.events))}


class DeskHTTP(SimpleHTTPRequestHandler):
    def __init__(self,*args,desk,allowed_host,connectors,**kwargs):
        self.desk,self.allowed_host,self.connectors=desk,allowed_host,connectors
        super().__init__(*args,**kwargs)

    def do_GET(self):
        if self.headers.get("Host")!=self.allowed_host:
            self.send_error(HTTPStatus.FORBIDDEN)
            return
        route=urlsplit(self.path).path
        if route=="/api/desk":
            self.json_response(self.desk.status())
        elif route=="/api/connectors":
            self.json_response(self.connector_status())
        elif route.startswith("/api/"):
            self.send_error(HTTPStatus.NOT_FOUND)
        else:
            super().do_GET()

    def do_POST(self):
        origin=f"http://{self.allowed_host}"
        if (self.headers.get("Host")!=self.allowed_host or self.headers.get("Origin")!=origin
                or self.headers.get_content_type()!="application/json"):
            self.send_error(HTTPStatus.FORBIDDEN)
            return
        if urlsplit(self.path).path!="/api/desk":
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        try:
            size=int(self.headers.get("Content-Length","0"))
            if not 0<size<=4096:
                raise ValueError("invalid request size")
            payload=json.loads(self.rfile.read(size))
            if not isinstance(payload,dict) or not isinstance(payload.get("settings",{}),dict):
                raise ValueError("expected a JSON object")
            self.desk.setup(payload.get("action"),payload.get("settings",{}))
            self.json_response(self.desk.status())
        except (TypeError,ValueError,InvalidOperation) as error:
            self.json_response({"error":str(error)},HTTPStatus.BAD_REQUEST)

    def connector_status(self):
        if not self.connectors:
            return []
        from trading_ui_connectors import read_trading_ui
        results=[]
        for name,settings in self.connectors.items():
            try:
                results.append(read_trading_ui(name,**settings))
            except (ValueError,OSError):
                results.append({"source":name,"state":"unavailable","metrics":{},"endpoints":{}})
        return results

    def json_response(self,value,status=HTTPStatus.OK):
        content=json.dumps(value,separators=(",",":"),allow_nan=False).encode()
        self.send_response(status)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Cache-Control","no-store")
        self.send_header("Content-Length",str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def log_message(self,format,*args):
        return


def main():
    parser=ArgumentParser(description=__doc__)
    parser.add_argument("--port",type=int,default=8132)
    for name in ("freqtrade","hummingbot"):
        parser.add_argument(f"--{name}-api")
        parser.add_argument(f"--{name}-ui")
    args=parser.parse_args()
    if not 1024<=args.port<=65535:
        parser.error("choose an unprivileged TCP port")
    connectors={}
    for name in ("freqtrade","hummingbot"):
        api=getattr(args,name+"_api")
        ui=getattr(args,name+"_ui")
        if ui and not api:
            parser.error(f"--{name}-ui requires --{name}-api")
        if api:
            connectors[name]={"api_url":api,"ui_url":ui}
    desk=Desk()
    stop=Event()
    directory=Path(__file__).resolve().parents[1]/"site"
    server=ThreadingHTTPServer(("127.0.0.1",args.port),
           partial(DeskHTTP,desk=desk,allowed_host=f"127.0.0.1:{args.port}",connectors=connectors,directory=directory))
    Thread(target=desk.reader,args=(stop,),daemon=True).start()
    print(f"http://127.0.0.1:{args.port}/desk.html",flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        stop.set()
        server.server_close()


if __name__=="__main__":
    main()
