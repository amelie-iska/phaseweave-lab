"""Score a timestamped net portfolio ledger using explicit annualization."""

from argparse import ArgumentParser
import csv
from datetime import date
from hashlib import file_digest
import json
import math
from pathlib import Path
from statistics import fmean, stdev


def score(dates,net,benchmark,riskfree,*,periods_per_year=252):
    count=len(dates)
    if count<2 or any(len(column)!=count for column in (net,benchmark,riskfree)):
        raise ValueError("expected at least two aligned observations")
    if periods_per_year<1 or not math.isfinite(periods_per_year):
        raise ValueError("annualization factor must be positive and finite")
    if any(a>=b for a,b in zip(dates,dates[1:])):
        raise ValueError("portfolio dates must be unique and ascending")
    if any(not math.isfinite(value) or value<=-1 for col in (net,benchmark,riskfree) for value in col):
        raise ValueError("expected finite simple return fractions above -1")
    log_nav=peak=0.0
    max_drawdown=0.0
    for ret in net:
        log_nav+=math.log1p(ret)
        peak=max(peak,log_nav)
        max_drawdown=min(max_drawdown,math.expm1(log_nav-peak))
    excess=[ret-rf for ret,rf in zip(net,riskfree,strict=True)]
    active=[ret-b for ret,b in zip(net,benchmark,strict=True)]
    annualizer=math.sqrt(periods_per_year)

    def ratio(values):
        volatility=stdev(values)
        return annualizer*fmean(values)/volatility if volatility>0 else None

    return {"observations":count,"start":dates[0].isoformat(),"stop_inclusive":dates[-1].isoformat(),
            "periods_per_year":periods_per_year,"sample_std_ddof":1,
            "cumulative_net_return":math.expm1(log_nav),"arr":math.expm1(log_nav*periods_per_year/count),
            "avol":annualizer*stdev(net),"mdd":max_drawdown,"asr":ratio(excess),"ir":ratio(active)}


def read(path):
    with path.open(newline="") as stream:
        rows=csv.DictReader(stream)
        required={"date","net_return","benchmark_return","risk_free_return"}
        if not required.issubset(rows.fieldnames or []):
            raise ValueError("CSV must include "+", ".join(sorted(required)))
        dates,net,benchmark,riskfree=[],[],[],[]
        for row in rows:
            scenario={field:float(row[field]) for field in required-{"date"}}
            dates.append(date.fromisoformat(row["date"]))
            net.append(scenario["net_return"])
            benchmark.append(scenario["benchmark_return"])
            riskfree.append(scenario["risk_free_return"])
    return dates,net,benchmark,riskfree


if __name__=="__main__":
    parser=ArgumentParser(description=__doc__)
    parser.add_argument("ledger",type=Path)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--periods-per-year",type=int,default=252)
    args=parser.parse_args()
    with args.ledger.open("rb") as stream:
        digest=file_digest(stream,"sha256").hexdigest()
    metrics=score(*read(args.ledger),periods_per_year=args.periods_per_year)
    with args.output.open("x") as stream:
        json.dump({"input_sha256":digest,**metrics},stream,indent=2,allow_nan=False)
        stream.write("\n")
