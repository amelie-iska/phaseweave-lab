"""Read aggregate operational health from explicitly configured loopback trading UIs.

Freqtrade GET routes: https://www.freqtrade.io/en/stable/rest-api/
Hummingbot GET routes: https://hummingbot.org/hummingbot-api/routers/
Opt-in HTTP Basic pairs: PHASEWEAVE_FREQTRADE_{USERNAME,PASSWORD} and
PHASEWEAVE_HUMMINGBOT_{USERNAME,PASSWORD}. No credentials are needed to import.
"""
import base64
import http.client
import ipaddress
import json
import math
import os
import socket
import ssl
import time
from urllib.parse import urlsplit

_FREQ = ("/api/v1/ping", "/api/v1/show_config", "/api/v1/status", "/api/v1/profit")
_HUM = ("/bot-orchestration/status",)
_LIMIT = 2 * 1024 * 1024
_FREQUENCY_STATES = {"running", "stopped", "reload_config", "paused"}
_BOT_STATES = {"running", "stopping", "idle", "stopped", "error", "not_found"}


def _local_url(value, *, ui=False, source=None):
    if not isinstance(value, str) or not value or any(ord(c) < 33 or ord(c) == 127 for c in value) or "\\" in value:
        raise ValueError("supply an explicit loopback HTTP(S) URL")
    parts = urlsplit(value)
    if parts.scheme not in ("http", "https") or parts.username is not None or parts.password is not None:
        raise ValueError("expected a loopback HTTP(S) URL without user information")
    if parts.query or parts.fragment or "%" in parts.netloc:
        raise ValueError("URL cannot include a query, fragment or scope ID")
    hostname = parts.hostname or ""
    if hostname == "localhost":
        address = "127.0.0.1"
    else:
        try:
            ip = ipaddress.ip_address(hostname)
        except ValueError:
            raise ValueError("expected localhost or a literal loopback address") from None
        if not ip.is_loopback:
            raise ValueError("destination must be loopback")
        address = str(ip)
    port = parts.port
    if port == 0:
        raise ValueError("port must be positive")
    if not ui:
        roots = ("/", "", "/api/v1", "/api/v1/") if source == "freqtrade" else ("", "/")
        if parts.path not in roots:
            raise ValueError("API URL must be an origin or the Freqtrade API root")
    elif parts.path.startswith("//"):
        raise ValueError("UI link must have a local path")
    return parts, address, port or (443 if parts.scheme == "https" else 80)


def _auth(source):
    prefix = "PHASEWEAVE_" + source.upper()
    username = os.environ.get(prefix + "_USERNAME")
    password = os.environ.get(prefix + "_PASSWORD")
    if not username and not password:
        return None
    if not username or not password or ":" in username:
        raise ValueError("configure both connector credentials and a username without a colon")
    encoded = base64.b64encode(f"{username}:{password}".encode("utf-8")).decode("ascii")
    return "Basic " + encoded


def _read(origin, path, auth, timeout):
    parts, address, port = origin
    # Connect to a literal loopback IP. Preserve the configured hostname for TLS
    # verification and the Host header. http.client follows no redirects or proxies.
    connection = http.client.HTTPConnection(address, port, timeout=timeout)
    status = None
    try:
        if parts.scheme == "https":
            context = ssl.create_default_context()
            with socket.create_connection((address, port), timeout=timeout) as sock:
                connection.sock = context.wrap_socket(sock, server_hostname=parts.hostname)
        headers = {"Accept":"application/json", "Accept-Encoding":"identity", "Host":parts.netloc}
        if auth:
            headers["Authorization"] = auth
        connection.request("GET", path, headers=headers)
        response = connection.getresponse()
        status = response.status
        if status != 200:
            return status, None
        raw = response.read(_LIMIT + 1)
        if len(raw) > _LIMIT:
            return status, None
        return status, json.loads(raw)
    except (OSError, http.client.HTTPException, ValueError, RecursionError):
        return status, None
    finally:
        connection.close()


def _freq_metrics(path, body, metrics):
    if path == _FREQ[0]:
        return isinstance(body, dict) and body.get("status") == "pong"
    if path == _FREQ[2]:
        if not isinstance(body, list) or not all(isinstance(row, dict) for row in body):
            return False
        metrics["open_positions"] = len(body)
        return True
    if not isinstance(body, dict):
        return False
    if path == _FREQ[1]:
        state = body.get("state")
        if isinstance(state, str) and state.lower() in _FREQUENCY_STATES:
            metrics["bot_state"] = state.lower()
        if isinstance(body.get("dry_run"), bool):
            metrics["dry_run"] = body["dry_run"]
        return "bot_state" in metrics or "dry_run" in metrics
    for key in ("closed_trade_count", "winning_trades", "losing_trades"):
        if type(body.get(key)) is int and body[key] >= 0:
            metrics[key] = body[key]
    return any(key in metrics for key in ("closed_trade_count", "winning_trades", "losing_trades"))


def _hum_metrics(body, metrics):
    if not isinstance(body, dict) or body.get("status") != "success" or not isinstance(body.get("data"), dict):
        return False
    rows = body["data"].values()
    counts = {key:0 for key in sorted(_BOT_STATES | {"unknown"})}
    for row in rows:
        status = row.get("status") if isinstance(row, dict) else None
        label = status if isinstance(status, str) and status in _BOT_STATES else "unknown"
        counts[label] += 1
    metrics.update(managed_bots=len(rows), bots_by_state=counts)
    return True


def read_trading_ui(source: str, *, api_url: str, ui_url: str | None = None,
                    timeout: float = 2.0) -> dict:
    """Return aggregate state, allowlisted metrics, per-route HTTP codes, and an optional UI link.

    State is available, partial, authentication_required or unavailable.
    An endpoint HTTP code of None means no response was received before the poll ended.
    FreqUI may share the Freqtrade origin. Hummingbot Dashboard needs its own explicit UI URL.
    """
    if source not in ("freqtrade", "hummingbot"):
        raise ValueError("unsupported trading UI source")
    if not isinstance(timeout,(int,float)) or isinstance(timeout,bool) or not math.isfinite(timeout) or timeout <= 0:
        raise ValueError("timeout must be finite and positive")
    origin = _local_url(api_url, source=source)
    if ui_url is not None:
        _local_url(ui_url, ui=True)
    elif source == "freqtrade":
        ui_url = f"{origin[0].scheme}://{origin[0].netloc}/"
    auth = _auth(source)
    paths = _FREQ if source == "freqtrade" else _HUM
    codes = dict.fromkeys(paths)
    metrics = {}
    completed = 0
    deadline = time.monotonic() + timeout
    for path in paths:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        status, body = _read(origin, path, None if path == _FREQ[0] else auth, remaining)
        codes[path] = status
        if status is None:
            break
        if status == 200:
            valid = _freq_metrics(path, body, metrics) if source == "freqtrade" else _hum_metrics(body, metrics)
            completed += int(valid)
    if completed == len(paths):
        state = "available"
    elif completed:
        state = "partial"
    elif any(code in (401,403) for code in codes.values()):
        state = "authentication_required"
    else:
        state = "unavailable"
    return {"source":source, "state":state, "ui_url":ui_url, "metrics":metrics, "endpoints":codes}
