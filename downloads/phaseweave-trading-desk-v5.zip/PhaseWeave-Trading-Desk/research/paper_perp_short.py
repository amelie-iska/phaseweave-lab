"""Offline, single-entry linear perpetual short ledger. All depth sizes are contract counts."""
import argparse
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, localcontext
import hashlib
import json
from pathlib import Path

ZERO = Decimal(0)
ONE = Decimal(1)


def number(value, field):
    if isinstance(value, bool) or not isinstance(value, (Decimal, int, str)):
        raise ValueError(f"{field} requires a decimal string, Decimal or integer")
    try:
        out = Decimal(value)
    except InvalidOperation as exc:
        raise ValueError(f"invalid {field}") from exc
    if not out.is_finite():
        raise ValueError(f"nonfinite {field}")
    return out


def positive(value, field):
    out = number(value, field)
    if out <= 0:
        raise ValueError(f"{field} must be positive")
    return out


def nonnegative_int(value, field):
    if type(value) is not int or value < 0:
        raise ValueError(f"{field} must be a nonnegative integer")
    return value


def digest(value):
    raw = json.dumps(value, sort_keys=True, separators=(",",":"), default=str, allow_nan=False)
    return hashlib.sha256(raw.encode()).hexdigest()


def wire(value):
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, dict):
        return {key:wire(val) for key,val in value.items()}
    if isinstance(value, list):
        return [wire(val) for val in value]
    return value


@dataclass(frozen=True)
class Terms:
    contract: str
    multiplier: Decimal
    step: Decimal
    collateral: Decimal
    initial: Decimal
    maintenance: Decimal
    fee: Decimal

    @classmethod
    def read(cls, spec):
        keys = {"contract","multiplier","contract_step","initial_margin_rate","maintenance_rate","taker_fee_rate","collateral"}
        if set(spec) != keys or not isinstance(spec["contract"],str) or not spec["contract"].strip():
            raise ValueError("expected explicit linear contract, quantity, cost and collateral terms")
        t = cls(spec["contract"],positive(spec["multiplier"],"multiplier"),
                positive(spec["contract_step"],"contract_step"),positive(spec["collateral"],"collateral"),
                positive(spec["initial_margin_rate"],"initial_margin_rate"),
                positive(spec["maintenance_rate"],"maintenance_rate"),number(spec["taker_fee_rate"],"taker_fee_rate"))
        if not ZERO < t.maintenance < t.initial <= ONE or not ZERO <= t.fee < ONE:
            raise ValueError("invalid initial, maintenance or fee rates")
        return t

    def quantity(self, value):
        q = positive(value,"contracts")
        if q % self.step:
            raise ValueError("contract count must follow contract_step")
        return q


def walk(levels, requested, terms, opening):
    if not isinstance(levels,(list,tuple)):
        raise ValueError("expected price levels")
    fills = []
    remaining = requested
    previous = None
    for entry in levels:
        if not isinstance(entry,(list,tuple)) or len(entry)!=2:
            raise ValueError("expected a (price, contracts) level")
        p = positive(entry[0],"level price")
        q = terms.quantity(entry[1])
        if previous is not None and (p >= previous if opening else p <= previous):
            raise ValueError("expected distinct descending bids or ascending asks")
        previous = p
        take = min(remaining,q)
        if take:
            fills.append({"price":p,"contracts":take,"notional":take*terms.multiplier*p})
            remaining -= take
    return fills,remaining


@dataclass
class Position:
    terms: Terms
    status: str = "waiting"
    contracts: Decimal = ZERO
    entry_basis: Decimal = ZERO
    mark: Decimal = ZERO
    realized: Decimal = ZERO
    fees: Decimal = ZERO
    funding: Decimal = ZERO
    trigger_mark: Decimal | None = None
    trigger_ms: int | None = None
    cover_gap_cost: Decimal = ZERO

    def values(self):
        notional = self.contracts*self.terms.multiplier*self.mark
        u = self.entry_basis-notional
        cash = self.terms.collateral+self.realized+self.funding-self.fees
        equity = cash+u
        maintenance = notional*(self.terms.maintenance+self.terms.fee)
        return {"status":self.status,"remaining_contracts":self.contracts,
                "signed_underlying":-self.contracts*self.terms.multiplier,"mark":self.mark,
                "remaining_entry_basis":self.entry_basis,"mark_notional":notional,
                "gross_realized_pnl":self.realized,"unrealized_pnl":u,"fees":self.fees,
                "funding_cashflow":self.funding,"collateral_cash":cash,"marked_equity":equity,
                "maintenance_including_exit_fee":maintenance,"maintenance_headroom":equity-maintenance,
                "negative_equity_gap":max(ZERO,-equity),"breach_mark":self.trigger_mark,
                "breach_ms":self.trigger_ms,"forced_cover_gap_cost":self.cover_gap_cost}

    def observe_breach(self, t):
        v = self.values()
        if self.status=="open" and self.contracts and v["marked_equity"] <= v["maintenance_including_exit_fee"]:
            self.trigger_mark,self.trigger_ms,self.status = self.mark,t,"cover_pending"

    def fill(self, event, t):
        opening = event["kind"]=="open"
        if opening and self.status!="waiting":
            raise ValueError("expected one opening instruction")
        if not opening and self.status not in {"open","cover_pending"}:
            raise ValueError("no short position to cover")
        q = self.terms.quantity(event["contracts"])
        if not opening and q>self.contracts:
            raise ValueError("reduce-only cover exceeds open short")
        if self.status=="cover_pending" and q!=self.contracts:
            raise ValueError("a maintenance cover must request all remaining contracts")
        sides = "bids" if opening else "asks"
        fills,unfilled = walk(event[sides],q,self.terms,opening)
        if self.status=="cover_pending" and t<=self.trigger_ms:
            return {"action":"await_subsequent_book","filled_contracts":ZERO,"unfilled_contracts":q,"fills":[]}
        filled = q-unfilled
        cost = sum((v["notional"] for v in fills),ZERO)
        fees = cost*self.terms.fee
        if opening:
            mark_value = filled*self.terms.multiplier*self.mark
            opening_equity = self.terms.collateral-fees+cost-mark_value
            if opening_equity < mark_value*(self.terms.initial+self.terms.fee):
                raise ValueError("insufficient isolated initial margin for candidate fills")
            self.contracts,self.entry_basis = filled,cost
            self.status = "open" if filled else "unfilled"
            action = "sell_to_open"
        else:
            # Allocate entry cost proportionally; the last fill consumes the exact remaining basis.
            basis = self.entry_basis if filled==self.contracts else self.entry_basis*filled/self.contracts
            self.realized += basis-cost
            self.entry_basis -= basis
            self.contracts -= filled
            forced = self.status=="cover_pending"
            if forced:
                self.cover_gap_cost += cost-filled*self.terms.multiplier*self.trigger_mark
            if self.contracts==0:
                self.status = "closed"
            action = "maintenance_buy_to_cover" if forced else "buy_to_cover"
        self.fees += fees
        self.observe_breach(t)
        return {"action":action,"filled_contracts":filled,"unfilled_contracts":unfilled,
                "fill_notional":cost,"fill_fee":fees,"fills":fills}


def replay(spec, events):
    """Return a fresh deterministic paper ledger from an ordered stream of observations."""
    with localcontext() as ctx:
        ctx.prec = 50
        return _replay(Terms.read(spec),spec,events)


def _replay(terms, spec, events):
    state = Position(terms)
    seen,settlements,ledger = {},set(),[]
    last_ms = last_book = -1
    fields = {"open":{"contracts","bids","book_id"}, "cover":{"contracts","asks","book_id"},
              "mark":set(), "funding":{"settlement_ms","rate"}}
    for e in events:
        kind = e.get("kind")
        if kind not in fields or set(e)!={"id","kind","at_ms","contract","mark"}|fields[kind]:
            raise ValueError("unknown event kind or malformed event fields")
        if e["contract"]!=terms.contract or not isinstance(e["id"],str) or not e["id"].strip():
            raise ValueError("event needs a matching contract and stable source identifier")
        fingerprint = digest(e)
        if e["id"] in seen:
            if seen[e["id"]]!=fingerprint:
                raise ValueError("conflicting replay of source event")
            continue
        t = nonnegative_int(e["at_ms"],"at_ms")
        if t<last_ms:
            raise ValueError("events are out of chronological order")
        if state.status=="waiting" and kind!="open":
            raise ValueError("the observed stream must start with its entry instruction")
        state.mark = positive(e["mark"],"mark")
        if kind in {"cover","mark"}:
            state.observe_breach(t)
        result = {"action":kind}
        if kind in {"open","cover"}:
            book = nonnegative_int(e["book_id"],"book_id")
            if book<=last_book:
                raise ValueError("book snapshots must advance; displayed capacity cannot be reused")
            result = state.fill(e,t)
            last_book = book
        elif kind=="funding":
            if nonnegative_int(e["settlement_ms"],"settlement_ms")!=t or t in settlements:
                raise ValueError("expected exactly one applied funding event at its effective settlement time")
            rate = number(e["rate"],"applied rate")
            transfer = state.contracts*terms.multiplier*state.mark*rate
            state.funding += transfer
            settlements.add(t)
            state.observe_breach(t)
            result.update(funding_cashflow=transfer,rate=rate)
        seen[e["id"]] = fingerprint
        last_ms = t
        ledger.append(wire({"id":e["id"],"input_sha256":fingerprint,"at_ms":t,"kind":kind,
                            **result,"state":state.values()}))
    return {"format":"phaseweave.paper-linear-perp-short.v1","contract":terms.contract,
            "spec_sha256":digest(spec),"state":wire(state.values()),"events":ledger}


if __name__=="__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("input",type=Path,help="JSON object with spec and events")
    p.add_argument("--output",type=Path,required=True)
    args = p.parse_args()
    source = json.loads(args.input.read_text(),parse_float=Decimal)
    report = replay(source["spec"],source["events"])
    report["input_file_sha256"] = hashlib.sha256(args.input.read_bytes()).hexdigest()
    with args.output.open("x") as stream:
        json.dump(report,stream,indent=2,sort_keys=True,allow_nan=False)
        stream.write("\n")
