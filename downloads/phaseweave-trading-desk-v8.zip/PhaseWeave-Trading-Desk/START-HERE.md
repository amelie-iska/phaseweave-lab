# PhaseWeave Trading Desk v8

Extract the full archive. Use Python 3.10 or later. No Python packages need to be installed.

- Windows: double-click `Start-Desk.cmd`, or run `py -3 research/trading_desk.py`.
- macOS: open `Start-Desk.command`, or run `sh ./Start-Desk.command` from this directory.
- Linux: run `sh ./Start-Desk.command` from this directory.

Open http://127.0.0.1:8132/desk.html in your browser after the server displays its
address. The server and paper session are local. Click Connect live quotes to
request public market data. Arm paper cycles only when you want to simulate fills.

For the professional workbench, use the connector flags for local Freqtrade or
Hummingbot instances described in README.md. Commercial licensing is by
agreement. See COMMERCIAL.md and LICENSE.

v8 adds the launchers and this guide. The underlying desk and its bundled
reference pages come from the public v7 package.
