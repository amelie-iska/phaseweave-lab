@echo off
setlocal
cd /d "%~dp0"
where py >NUL 2>NUL
if errorlevel 1 goto use_python
py -3 research\trading_desk.py %*
goto finished
:use_python
python research\trading_desk.py %*
:finished
set "result=%errorlevel%"
if not "%result%"=="0" pause
exit /b %result%
