# Matched generation and terminal editing of FX teacher forests

Four conditional generators fit the fixed final checkpoint on 1,973 selected August contexts, then generated forests on 377 September validation contexts. Both flow-matching seeds had lower validation energy score than their paired DDPM seed. The August mean had the lowest sample-mean RMSE. The shared terminal editor improved verifier fit in all four runs and reduced one-second margin MAE in three. Random and fixed topological order gave similar MAE. These findings concern a 16-root teacher-conditioned skeleton, two generator seeds and one validation population. [Rough-generation receipt](../evaluations/rough-forest-cpu-v1.json) · [Editor receipt](../evaluations/rough-forest-editor-v1.json)

## Shared data and model

Each context has 19 observed standardized features and 16 **given** teacher roots. Every root has two eight-stage finalist ancestries plus a ninth-slot attempted repair of finalist two. The known root occurs once. Shared prefixes between the two finalist paths are unfolded into separate slots, yielding 17 free 3D slots per root (816 fitted coordinates per forest). The repair's ancestral history is carried by finalist two. Raw teacher ancestry and active-frame masks are verified before training. An attempted terminal repair can be physically infeasible. The generators receive the same skeleton and context, independent of the teacher's terminal eligibility and cost arrays.

Targets are private model-derived states anchored on observed FX windows. August uses in-sample teacher distillation. The sampler conditions on a real teacher root, so a forecast requires the root-producing network or supplied roots. The generator learns continuous state values for a given topology. It provides neither a variable-branch topology law nor an independent estimate of the root distribution. Seven teacher abstentions were excluded from the 384 sampled September windows. Only 377 retained rows participate in every comparison. [Teacher cache and sample hashes](EDITED_PATH_GFLOWNET.md)

For each slot, subtract its root, center using its August residual mean and divide by its August residual SD with floor .05. A 42,163-parameter shared network encodes all 51 coordinates per root, tree embedding, known root, context and time. A global mean over the 16 encoded roots feeds the joint output. Both arms use the same initial weights per seed, batches, standard-Gaussian noise, 768 AdamW updates of 32, learning rate .001, weight decay .001, gradient norm 2 and the final checkpoint. Four draws per September context use matched starting noise. Each full forest uses 32 field evaluations.

The flow arm regresses the straight interpolation velocity (target minus independent Gaussian start) and samples by 32 deterministic Euler steps. The DDPM arm uses a 32-step shifted cosine cumulative-noise schedule, beta clipped to [.000001,.999]. It regresses velocity parameterization, converts the prediction to a clean-state estimate and uses the Gaussian DDPM posterior transition with fresh noise except at the final step. The straight-flow objective and DDPM loss have different units. No sample likelihood is assigned to the Euler trajectories. [Flow Matching](https://arxiv.org/abs/2210.02747) · [DDPM](https://arxiv.org/abs/2006.11239)

| Arm and seed suffix | Energy score ↓ | Expected sample RMS | Sample-mean RMS | Diversity RMS | Terminal mean MAE |
|---|---:|---:|---:|---:|---:|
| August mean | .232825 | .232825 | .232825 | .000000 | .129109 |
| FM 210 | .151044 | .315648 | .242263 | .329208 | .120474 |
| DDPM 210 | .152674 | .297592 | .238049 | .289837 | .124545 |
| FM 211 | .150129 | .315914 | .241271 | .331570 | .117701 |
| DDPM 211 | .161406 | .308610 | .248769 | .294407 | .134264 |

The complete seed IDs are 20261210 and 20261211. RMS uses the original teacher-standardized state units over 816 free coordinates. The energy score subtracts half the mean distance between distinct generated draws from the mean distance to the observed teacher realization. A deterministic mean has zero diversity. The seed-paired energy differences (FM minus DDPM) were −.001629 and −.011277. The terminal column compares the *mean of four draws* to the three teacher endpoints per tree. All columns are conditional on the given roots; error on the physical forecast is evaluated separately below.

## Common autoregressive terminal editor

A separate 7,640-parameter conditional Gaussian editor fit 640 batches of 96 August windows with supervised, noisy **latent** endpoint reconstruction. Only the fitted model's 3D states were perturbed. Its input includes root and terminal type, context, upstream state, rough endpoint and mean previously committed displacement. Teacher forcing uses random topological orders. At inference every original candidate remains reachable on its original ancestry. Each new proposal is added with its actual immutable parent. Strong and weak finalists are eligible initially, and each attempted repair follows its weak finalist. A feasible lower-cost proposal can win the slot; a proposed repair must also improve its own weak parent or repair its physical infeasibility. [Prespecified editor design](ROUGH_FOREST_EDITOR_DESIGN.md)

The fixed and random arms use the same editor and 48 coordinate-keyed normal innovations per context. A randomized Gaussian-only control proposes isotropic scale .20 independently of the editor. Each edit arm scores 48 additional candidates. No-edit scores the 48 originals alone. Only terminal states are eligible for revision. Earlier expansion ancestors remain fixed. This is an endpoint editor with a causal state, rather than a full-depth structural rewriter.

| Arm and seed suffix | No edit | Fixed | Random eligible | Gaussian repair |
|---|---:|---:|---:|---:|
| FM 210 | .184574 | .183359 | .183434 | .183991 |
| DDPM 210 | .182544 | .183456 | .183443 | .182248 |
| FM 211 | .184829 | .183960 | .183978 | .183997 |
| DDPM 211 | .187046 | .184567 | .184533 | .186254 |

Entries are September mean absolute errors in log bp across both directions at one second. A single seeded rough draw per context was held fixed across editor controls. Each eligible tree nominates its best feasible candidate by the frozen verifier; the componentwise midpoint median over tree votes gives the forecast. All methods covered all 377 teacher-admitted contexts across 13 days. Matching the 19 observed features against the frozen archive identified all rows uniquely and in sample order before their forecast targets were scored. The depth-matched teacher scored .183564, the direct verifier .186274 and persistence .243404. Random editing reduced mean verifier cost from .1486 to .1067 for FM 210, from .1491 to .1079 for DDPM 210, from .1418 to .1070 for FM 211 and from .1592 to .1108 for DDPM 211. The second example improved the verifier and worsened future-margin error.

The saved private audit records all 217,152 appended terminal proposals across four rough fits, three proposal arms, 377 contexts and 48 slots. An independent replay checked every parent, reachable winner, feasibility decision and selected ID. The public receipts carry aggregates and file hashes. Sampling diversity here concerns model-generated latent forests. The pilot has no October or CHF generator evaluation, estimates no trading returns, and supports no ranking beyond this validation comparison.

## Reproduce

In the project's existing research environment, provide the hash-pinned teacher cache, frozen August verifier and data archive. Use fresh output directories.

```sh
export CUDA_VISIBLE_DEVICES='' OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=2
python -B research/train_rough_forest.py --output runs/rough-forest-reproduction
python -B research/edit_rough_forest.py --rough runs/rough-forest-reproduction --output runs/rough-editor-reproduction
python -B research/check_rough_forest.py --run runs/rough-editor-reproduction
```
