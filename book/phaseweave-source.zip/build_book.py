"""Build the standalone TeX and HTML field guide using only the standard library."""
from pathlib import Path
from html import escape
import re
from itertools import groupby

root=Path(__file__).resolve().parent
src=root/'source'
chapters=[]
appendix_titles=[]
for path in sorted(src.glob('[0-9][0-9]-*.txt')):
    lines=iter(path.read_text().splitlines())
    for line in lines:
        if not line.strip():continue
        if line.startswith('# '):
            chapters.append((line[2:],[]))
            if path.name.endswith("-appendices.txt"):
                appendix_titles.append(line[2:])
            continue
        blocks=chapters[-1][1]
        if line.startswith('```'):
            code=[]
            for c in lines:
                if c.startswith('```'):break
                code.append(c)
            blocks.append(('code','\n'.join(code)))
        elif line.startswith('## '):blocks.append(('h',line[3:]))
        elif line.startswith('@ '):blocks.append(('figure',line[2:].split(' | ',1)))
        elif line.startswith('= '):blocks.append(('eq',line[2:].split(' | ',1)))
        elif line.startswith('! '):blocks.append(('link',line[2:].split(' | ',1)))
        elif line.startswith('|'):
            if not blocks or blocks[-1][0]!='table':blocks.append(('table',[]))
            blocks[-1][1].append(line.strip('|').split('|'))
        else:blocks.append(('p',line))
def tex(s):
    replacements={'&':r'\&','%':r'\%','_':r'\_','#':r'\#','$':r'\$','{':r'\{','}':r'\}','~':r'\textasciitilde{}','^':r'\textasciicircum{}','\\':r'\textbackslash{}','→':r'\ensuremath{\to}','−':r'\ensuremath{-}','⁻':r'\textsuperscript{-}','¹':r'\textsuperscript{1}','⁶':r'\textsuperscript{6}','⁵':r'\textsuperscript{5}','₁':r'\ensuremath{_1}','₂':r'\ensuremath{_2}','₃':r'\ensuremath{_3}','₄':r'\ensuremath{_4}','ᵢ':r'\ensuremath{_i}','†':r'\ensuremath{^\dagger}','μ':r'\ensuremath{\mu}','π':r'\ensuremath{\pi}','±':r'\ensuremath{\pm}','×':r'\ensuremath{\times}','⁄':'/'}
    return ''.join(replacements.get(c,c) for c in s)
header=r'''\documentclass[11pt,oneside,openany]{book}
\usepackage[paperwidth=6in,paperheight=9in,left=.66in,right=.62in,top=.72in,bottom=.72in,headheight=16pt,headsep=.17in,footskip=.32in]{geometry}
\usepackage{fontspec}
\setmainfont{Georgia}
\setsansfont{Arial}
\setmonofont{Courier New}[Scale=.89]
\usepackage{amsmath,amssymb,xcolor,booktabs,graphicx,adjustbox,tabularx,fancyhdr,fvextra,needspace,titlesec,microtype}
\definecolor{teal}{HTML}{105F59}\definecolor{gold}{HTML}{B56F36}\definecolor{ink}{HTML}{182B32}
\usepackage[colorlinks,linkcolor=teal,urlcolor=teal,pdftitle={PhaseWeave: A field guide to graph forecasting},pdfauthor={PhaseWeave research project},bookmarksdepth=1]{hyperref}
\setcounter{tocdepth}{0}
\setlength{\parindent}{0pt}\setlength{\parskip}{4.5pt plus 1pt minus 1pt}
\setlength{\emergencystretch}{2em}
\raggedbottom
\newcommand{\bookdivision}{Chapter}
\titleformat{\chapter}[display]{\normalfont\raggedright\color{ink}\sffamily\bfseries}{\color{teal}\small\MakeUppercase{\bookdivision{} \thechapter}}{5pt}{\huge}
\titlespacing*{\chapter}{0pt}{-12pt}{12pt}
\titleformat{\section}{\normalfont\color{teal}\large\sffamily\bfseries}{}{0pt}{}
\titlespacing*{\section}{0pt}{12pt plus 2pt}{2pt}
\pagestyle{fancy}\fancyhf{}\fancyhead[L]{\small\sffamily\color{teal}PhaseWeave}\fancyhead[R]{\small\sffamily Research edition}\fancyfoot[R]{\sffamily\thepage}
\renewcommand{\headrulewidth}{.3pt}
\fancypagestyle{plain}{\fancyhf{}\fancyfoot[R]{\sffamily\thepage}\renewcommand{\headrulewidth}{0pt}}
\DefineVerbatimEnvironment{BookCode}{Verbatim}{fontsize=\small,breaklines=true,breakanywhere=true,breaksymbolleft={},formatcom=\color{ink},xleftmargin=.1in,frame=leftline,rulecolor=\color{gold},framesep=5pt}
\begin{document}
\hypersetup{pageanchor=false}\begin{titlepage}
\color{ink}\vspace*{.40in}
{\sffamily\bfseries\color{teal} HISTORICAL MARKET REPLAY}\par\vspace{.35in}
{\sffamily\bfseries\fontsize{43}{45}\selectfont PhaseWeave}\par\vspace{.12in}
{\fontsize{22}{26}\selectfont A field guide to graph forecasting}\par
\vspace{.37in}{\color{gold}\rule{.7\linewidth}{1.6pt}}\par\vspace{.27in}
Directed exchange graphs, surface orders, cyclic qudits and learned forecasts\par
\vfill
{\sffamily Research edition\hfill 20 November 2026}\par
\end{titlepage}
\hypersetup{pageanchor=true}\tableofcontents
'''
styles='''
:root{--ink:#172d36;--accent:#12665f;--line:#d5ddd7;--paper:#fbfaf5;--gold:#b16d33}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:18px/1.57 Georgia,serif}a{color:var(--accent);text-underline-offset:.18em}header,nav,button,input,select,label,th,small,h1,h2,h3{font-family:system-ui,sans-serif}header{max-width:78rem;margin:auto;padding:3rem 2rem 2rem;border-bottom:1px solid var(--line)}h1{font-size:clamp(2.5rem,7vw,5rem);line-height:1;letter-spacing:-.055em;margin:.35em 0}header p{font-size:1.25rem;max-width:36em}main{display:grid;grid-template-columns:minmax(12rem,20rem) minmax(0,47rem);gap:3.5rem;max-width:78rem;margin:auto;padding:1.6rem 2rem}nav{position:sticky;top:1rem;align-self:start;max-height:94vh;overflow-y:auto;font-size:.87rem;padding-right:.75rem}nav ol{padding-left:1.7rem}nav li{margin:.33em 0}nav input{width:100%}article>section{scroll-margin-top:1rem;padding:.75rem 0 1.4rem;border-bottom:1px solid var(--line)}h2{font-size:2.1rem;line-height:1.17;letter-spacing:-.035em}h3{color:var(--accent);line-height:1.28;margin:1.65em 0 .3em}small{color:var(--accent);font-weight:650}pre,figure{margin:1em 0;padding:.8em 1em;background:#f0f2ec;border-left:3px solid var(--gold);overflow:auto}pre{font: .83rem/1.55 ui-monospace,monospace;tab-size:4}figure{font-size:1.16em}table{border-collapse:collapse;width:100%;font: .90rem/1.45 system-ui,sans-serif;font-variant-numeric:tabular-nums}td,th{padding:.42em .45em;border-bottom:1px solid var(--line);text-align:right}td:first-child,th:first-child{text-align:left}th{color:var(--accent)}.scroll{overflow:auto;margin:1em 0}button,select,input{font-size:1rem;padding:.4em .5em}button{cursor:pointer}label{display:block;margin:.6em 0}input[type=range]{width:min(24em,95%);vertical-align:middle}output{display:block;font-variant-numeric:tabular-nums;font-weight:600}details{margin:1em 0;padding:.85em;border:1px solid var(--line)}summary{cursor:pointer;color:var(--accent);font-family:system-ui,sans-serif;font-weight:650}iframe{width:100%;height:34rem;border:1px solid var(--line)}.skip{position:absolute;left:-10000px}.skip:focus{left:1em;background:white}.by{color:var(--accent);font-weight:650}.tool{padding:1em 1.25em;margin:1em 0;border:1px solid var(--line);background:white}.tool h3{margin:0 0 .5em}.math{font-family:Georgia,serif}.chapterfoot{font:.85rem system-ui,sans-serif;display:flex;gap:1rem;justify-content:space-between;margin:2em 0}.chapterfoot a{text-decoration:none}a:focus-visible,button:focus-visible,input:focus-visible,summary:focus-visible{outline:3px solid var(--gold)}@media(max-width:850px){main{display:block;padding:1rem}header{padding:2rem 1rem}nav{position:static;max-height:14rem;margin-bottom:1.5rem;border-bottom:1px solid var(--line)}h2{font-size:1.7rem}}
'''
tex_parts=[header]
toc=[];articles=[]
widgets=(src/'widgets.html').read_text().split('<!--SPLIT-->')
widgetat={'Two prices for every pair':widgets[0], 'A clock, a shift and a measurement':widgets[1], 'Directed persistence':widgets[2], 'Replay the public lab':widgets[3], 'Phase features by seed':widgets[4]}
for n,(title,blocks) in enumerate(chapters,1):
    key=f'ch-{n}'
    label=f'Chapter {n}'
    if title in appendix_titles:
        slot=appendix_titles.index(title)
        label='Appendix '+chr(ord('A')+slot)
        if slot==0:
            tex_parts.append(r'\appendix\renewcommand{\bookdivision}{Appendix}')
        toc.append(f'<li style="list-style:none"><a href="#{key}">{label}. {escape(title)}</a></li>')
    else:
        toc.append(f'<li><a href="#{key}">{escape(title)}</a></li>')
    page=[f'<section id="{key}"><small>{label}</small><h2>{escape(title)}</h2>']
    tex_parts.append(r'\chapter{'+tex(title)+'}')
    for kind,v in blocks:
        if kind=='p':
            tex_parts.append(tex(v)+'\n');page.append('<p>'+escape(v)+'</p>')
        elif kind=='h':
            tex_parts.append(r'\section*{'+tex(v)+'}');page.append('<h3>'+escape(v)+'</h3>')
        elif kind=='figure':
            tex_parts.append(r'\begin{center}\includegraphics[width=\linewidth]{figures/'+v[0]+r'.pdf}\par{\small '+tex(v[1])+r'}\end{center}')
            page.append('<figure><img style="max-width:100%;height:auto" src="figures/'+escape(v[0])+'.png" alt="'+escape(v[1],quote=True)+'"><figcaption>'+escape(v[1])+'</figcaption></figure>')
        elif kind=='eq':
            tex_parts.append(r'\begin{center}\begin{adjustbox}{max width=\linewidth}$\displaystyle '+v[0]+r'$\end{adjustbox}\end{center}');page.append('<figure class="math">'+escape(v[1])+'</figure>')
        elif kind=='link':
            tex_parts.append(r'{\small\sffamily\href{'+v[1]+'}{'+tex(v[0])+r'}\par}');page.append(f'<p><a href="{escape(v[1],quote=True)}">{escape(v[0])}</a></p>')
        elif kind=='code':
            tex_parts.append('\\begin{BookCode}\n'+v+'\n\\end{BookCode}');page.append('<pre><code>'+escape(v)+'</code></pre>')
        elif kind=='table':
            cols=len(v[0]);assert all(len(row)==cols for row in v)
            txcols='l'+'r'*(cols-1)
            tex_parts.extend([r'\begin{center}\footnotesize\sffamily\setlength{\tabcolsep}{3.5pt}\renewcommand{\arraystretch}{1.2}',r'\begin{adjustbox}{max width=\linewidth}\begin{tabular}{@{}'+txcols+r'@{}}\toprule'])
            page.append('<div class="scroll"><table><thead>')
            for i,row in enumerate(v):
                tex_parts.append(' & '.join(tex(c) for c in row)+r' \\'+(r' \midrule' if i==0 else ''))
                tag='th' if i==0 else 'td'
                page.append('<tr>'+''.join(f'<{tag}>{escape(c)}</{tag}>' for c in row)+'</tr>'+('</thead><tbody>' if i==0 else ''))
            tex_parts.append(r'\bottomrule\end{tabular}\end{adjustbox}\end{center}');page.append('</tbody></table></div>')
    if title in widgetat:page.append(widgetat[title])
    prev=f'<a href="#ch-{n-1}">← Previous chapter</a>' if n>1 else ''
    nxt=f'<a href="#ch-{n+1}">Next chapter →</a>' if n<len(chapters) else ''
    page.append(f'<div class="chapterfoot">{prev}<a href="#contents">Contents</a>{nxt}</div></section>')
    articles.append(''.join(page))
tex_parts.append(r'\end{document}')
(root/'phaseweave.tex').write_text('\n'.join(tex_parts)+'\n')
html='''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><link rel="icon" href="data:,"><title>PhaseWeave · A field guide to graph forecasting</title><style>'''+styles+'''</style></head><body><a class="skip" href="#ch-1">Skip to book</a><header><span class="by">HISTORICAL MARKET REPLAY</span><h1>PhaseWeave</h1><p>A field guide to graph forecasting</p><p>Directed exchange graphs, surface orders, cyclic qudits and learned forecasts.</p><a href="phaseweave.pdf">PDF edition</a> · <a href="phaseweave.tex">LaTeX source</a> · <a href="phaseweave-source.zip">Complete source bundle</a></header><main><nav id="contents" aria-label="Chapter navigation"><strong>Contents</strong><label>Find a chapter<input id="filter" type="search" placeholder="Filter chapter titles"></label><ol>'''+''.join(toc)+'''</ol></nav><article>'''+''.join(articles)+'''</article></main><script>'''+(src/'reader.js').read_text()+'''</script></body></html>'''
(root/'index.html').write_text(html)
print(f'{len(chapters)} chapters, {len(tex_parts)} blocks')
