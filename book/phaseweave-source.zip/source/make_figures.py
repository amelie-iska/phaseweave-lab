"""Generate standalone PGFPlots sources from aggregate records."""
from pathlib import Path
import statistics,json
src=Path(__file__).resolve().parent
fig=src.parent/'figures'
common=r'''\documentclass[border=4pt]{standalone}
\usepackage{pgfplots}
\pgfplotsset{compat=1.17}
\definecolor{teal}{HTML}{12665F}
\definecolor{copper}{HTML}{B46933}
\begin{document}\begin{tikzpicture}
'''
end=r'\end{axis}\end{tikzpicture}\end{document}'
def coords(pairs):return ' '.join('('+str(x)+','+f'{y:.7f}'+')' for x,y in pairs)
history=json.loads((src/'width200-history.json').read_text())
(fig/'validation.tex').write_text(common+r'''\begin{axis}[width=12.2cm,height=6.1cm,xlabel={Full epochs},ylabel={Validation MAE (log bps)},xmin=1,xmax=23,xtick={1,5,10,15,20,23},ymin=.17,ymax=.233,ymajorgrids,grid style={black!10},legend style={font=\small,draw=none},legend pos=north east,scaled y ticks=false]
\addplot[teal,very thick,mark=*,mark size=1.1pt] coordinates {'''+coords((e,y) for e,y,_ in history)+r'''};
\addlegendentry{Width 200}
\addplot[copper,dashed,thick] coordinates {(1,0.22791646) (23,0.22791646)};
\addlegendentry{Persistence}
'''+end)
d=json.loads((src/'phase-evaluation.json').read_text())['holdout']
names=['classical-softmax','classical-tropical','qutrit-softmax','qutrit-tropical','frozen_qutrit-softmax','frozen_qutrit-tropical']
ss=[('test','teal','*','October test'),('new_asset','copper','triangle*','Unseen CHF'),('stress','black!65','square*','Stress')]
tx=common+r'''\begin{axis}[width=12.2cm,height=6.8cm,ylabel={Mean MAE (log bps)},xmin=.6,xmax=6.4,xtick={1,2,3,4,5,6},xticklabels={C--S,C--T,Q--S,Q--T,F--S,F--T},ymin=.165,ymax=.226,ymajorgrids,grid style={black!10},legend style={font=\small,draw=none,at={(.48,1.08)},anchor=south,legend columns=3},scaled y ticks=false]'''
for i,(sp,color,mark,label) in enumerate(ss):
 ps=[(j+.12*(i-1), statistics.mean(r['learned']['mae_bps'] for r in d if r['split']==sp and r['run'].rsplit('-',1)[0]==key)) for j,key in enumerate(names,1)]
 tx+='\n'+r'\addplot[only marks,'+color+',mark='+mark+',mark size=2.4pt] coordinates {'+coords(ps)+'};\n'+r'\addlegendentry{'+label+'}'
(fig/'phase-means.tex').write_text(tx+'\n'+end)
