const byId = (id) => document.getElementById(id);
byId('filter').addEventListener('input', (event) => {
  const query = event.target.value.trim().toLowerCase();
  document.querySelectorAll('nav li').forEach((item) => {
    item.hidden = !item.textContent.toLowerCase().includes(query);
  });
});
function refreshMargin() {
  const cost = Number(byId('cost').value);
  const forward = 10000 * Math.log(6 / 6.0018) - 3 * cost;
  const reverse = 10000 * Math.log(6.0012 / (3.0003 * 2.0002)) - 3 * cost;
  byId('margin').textContent = Number(byId('age').value) < 280
    ? 'Both routes unavailable. The oldest pair exceeds the age limit.'
    : 'Cost ' + cost.toFixed(1) + ' per leg · Forward ' + forward.toFixed(5) + ' · Reverse ' + reverse.toFixed(5) + ' log bps';
}
function refreshQutrit() {
  const degrees = Number(byId('theta').value);
  const p = (5 + 4 * Math.cos(degrees * Math.PI / 180)) / 9;
  byId('measurement').textContent = degrees + '° · Probability of level zero after Fourier mixing ' + p.toFixed(5);
}
function refreshLandscape() {
  const t = Number(byId('threshold').value);
  const heights = [[0,4],[1,3]].map(([b,d]) => Math.max(0,Math.min(t-b,d-t))).sort((a,b) => b-a);
  byId('land').textContent = 'Threshold ' + t.toFixed(2) + ' · First layer ' + heights[0].toFixed(2) + ' · Second layer ' + heights[1].toFixed(2);
}
byId('cost').addEventListener('input',refreshMargin);
byId('age').addEventListener('change',refreshMargin);
byId('theta').addEventListener('input',refreshQutrit);
byId('threshold').addEventListener('input',refreshLandscape);
byId('openlab').addEventListener('click',(event) => {
  const frame = document.createElement('iframe');
  frame.title = 'PhaseWeave public market topology lab';
  frame.src = 'https://amelie-iska.github.io/phaseweave-lab/';
  byId('labholder').appendChild(frame);
  event.currentTarget.disabled = true;
});
function refreshComparison() {
  const split = byId('compare').value;
  const rows = phaseMeans[split].slice().sort((a,b) => a[1]-b[1]);
  const table = document.createElement('table');
  const header = table.createTHead().insertRow();
  ['Feature and attention','Mean MAE (log bps)'].forEach((title) => {
    const cell = document.createElement('th');
    cell.textContent = title;
    header.appendChild(cell);
  });
  const body = table.createTBody();
  rows.forEach(([variant,mae]) => {
    const row = body.insertRow();
    row.insertCell().textContent = variant;
    row.insertCell().textContent = mae.toFixed(6);
  });
  byId('compare-results').replaceChildren(table);
}
byId('compare').addEventListener('change',refreshComparison);
const phaseMeans = {"test": [["classical / softmax", 0.17202293872833252], ["classical / tropical", 0.17618388682603836], ["qutrit / softmax", 0.17341671884059906], ["qutrit / tropical", 0.17346306145191193], ["frozen qutrit / softmax", 0.18218979239463806], ["frozen qutrit / tropical", 0.1890854686498642]], "new_asset": [["classical / softmax", 0.1999148353934288], ["classical / tropical", 0.2194482833147049], ["qutrit / softmax", 0.19546141475439072], ["qutrit / tropical", 0.18767113983631134], ["frozen qutrit / softmax", 0.2021629512310028], ["frozen qutrit / tropical", 0.2181277647614479]], "stress": [["classical / softmax", 0.17469840496778488], ["classical / tropical", 0.1777353435754776], ["qutrit / softmax", 0.17490793764591217], ["qutrit / tropical", 0.17384205758571625], ["frozen qutrit / softmax", 0.18422500044107437], ["frozen qutrit / tropical", 0.19082453846931458]]};
refreshMargin(); refreshLandscape(); refreshQutrit(); refreshComparison();
