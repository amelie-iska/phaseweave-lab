"""Generate tables from the bundled aggregate evaluation receipts, with no network access."""
import json
import statistics
from pathlib import Path

here=Path(__file__).resolve().parent
read=lambda name:json.loads((here/name).read_text())
campaign=read('campaign.json')
phase=read('phase-evaluation.json')
assert len(campaign['runs'])==26 and len(phase['runs'])==12
assert phase['runs']==read('phase.json')
assert campaign['source_manifest_sha256']==phase['source_manifest_sha256']
lines=[]
def para(s):lines.append(s)
def table(rows):
    for row in rows:lines.append('|'+'|'.join(map(str,row))+'|')
    lines.append('')
def get(r,split):return next(x for x in all_scores if x['run']==r and x['split']==split)
def num(x):return f'{x:.6f}'
def short(x):
    return x.replace('frozen_qutrit','F').replace('qutrit','Q').replace('classical','C').replace('softmax','S').replace('tropical','T').replace('202611','')
all_scores=campaign['holdout']+phase['holdout']
para('# Campaign ledger')
para('The validation ledger gives both seeds for every hyperparameter setting. Within each two-run row, the lower run ID has seed 20261120 and the higher has seed 20261121. Both validation values are in log basis points. LR is the master learning rate, RO the readout multiplier and AT the attention multiplier. Each 200-wide proxy has eight heads and two blocks on each of the two model axes.')
rows=[['Runs','LR','RO','AT','Seed 20','Seed 21']]
for a,b in zip(campaign['runs'][:24:2],campaign['runs'][1:24:2]):
    c=a['config']
    rows.append([a['run'][-2:]+' / '+b['run'][-2:],c['learning_rate'],c['readout_multiplier'],c['attention_multiplier'],num(a['best_validation']),num(b['best_validation'])])
table(rows)
para('The two winning seeds have mean validation MAE '+num(campaign['selection']['group_scores'][0][0])+'. The initial first-family validation run has a separate denominator. All proxies used the same full-validation split for selection. The full checksums are bundled with the aggregate records.')
para('## What changed with width')
rows=[['Width','Parameters','Initial |h|','Final |h|','Residual']];rows[0]=['Width','Parameters','Initial act.','Final act.','Residual']
for item in campaign['coordinates']:
 p=item['points'];rows.append([item['width'],f"{item['parameters']:,}",f"{p[0]['activation_mean_abs']:.4f}",f"{p[-1]['activation_mean_abs']:.4f}",f"{p[-1]['mean_abs_residual_bps']:.5f}"])
table(rows)
para('Activation denotes the absolute mean of the last temporal block output. Residual is the mean absolute predicted change in log bps at the fourth forward pass. The last two wider runs had validation minima of '+num(campaign['runs'][-2]['best_validation'])+' and '+num(campaign['runs'][-1]['best_validation'])+', respectively.')
para('# Chronological and family holdouts')
para('The MAE, root mean squared error and 95th percentile of absolute error are measured across both route directions. The intervals below belong to paired MAE differences against persistence. Validation chose the settings before these runs were scored. The baseline is included once per split.')
for split,title in [('test','October development families'),('new_asset','October CHF families'),('stress','September dislocation')]:
 para('## '+title)
 selection=[r for r in campaign['holdout'] if r['split']==split]
 baseline=selection[0]['persistence']
 rows=[['Run','MAE','RMSE','P95 abs.'],['Persistence',num(baseline['mae_bps']),num(baseline['rmse_bps']),num(baseline['p95_absolute_error_bps'])]]
 for r in selection:
  m=r['learned'];rows.append([r['run'],num(m['mae_bps']),num(m['rmse_bps']),num(m['p95_absolute_error_bps'])])
 table(rows)
 rows=[['Run','Lower 95%','Upper 95%','Hits / proposals']]
 for r in selection:
  m=r['learned'];ci=r['mae_delta_bps_ci'];rows.append([r['run'],num(ci['lower_95']),num(ci['upper_95']),f"{m['positive_route_hits']} / {m['positive_proposals']}"])
 table(rows)
 para(f"This split has {selection[0]['rows']:,} windows in {selection[0]['mae_delta_bps_ci']['utc_day_blocks']} UTC day blocks, with {baseline['positive_windows']:,} positive windows. The persistence policy chose {baseline['positive_proposals']:,} positive routes, of which {baseline['positive_route_hits']:,} had a positive observed margin on that same route.")
para('# Phase features by seed')
para('C denotes the matched classical feature, Q a trainable four-qutrit feature and F a frozen qutrit encoder and couplings. S and T identify softmax and tropical aggregation. Seed suffixes 20 and 21 stand for 20261120 and 20261121. Every row is one fitted model. Parameter counts include only trainable parameters.')
rows=[['Run','Parameters','Validation','Test','CHF','Stress']]
for r in phase['runs']:
 rows.append([short(r['run']),f"{r['parameters']:,}",num(r['best_validation'])]+[num(get(r['run'],sp)['learned']['mae_bps']) for sp in ['test','new_asset','stress']])
table(rows)
para('The three holdout columns use frozen checkpoint selection. Selection by the average of the two validation seeds prefers classical softmax among these six configurations. The two-seed CHF mean separately favors the trainable qutrit tropical configuration. Picking the best configuration by CHF performance would consume that holdout for model selection.')
for split,title in [('test','October chronological diagnostics'),('new_asset','CHF family diagnostics'),('stress','Stress diagnostics')]:
 para('## '+title)
 rows=[['Run','RMSE','P95 abs.','Lower 95%','Upper 95%']]
 for r in phase['runs']:
  e=get(r['run'],split);c=e['mae_delta_bps_ci'];m=e['learned'];rows.append([short(r['run']),num(m['rmse_bps']),num(m['p95_absolute_error_bps']),num(c['lower_95']),num(c['upper_95'])])
 table(rows)
para('## Stress event counts')
para('For every row the denominator for recall is 2,679 positive windows. Precision divides verified hits by forecast-positive proposals. All quantities refer to the same sampled windows, so these counts cannot be summed across runs as independent evidence.')
rows=[['Run','Proposals','Hits','Precision','Recall']]
for r in phase['runs']:
 m=get(r['run'],'stress')['learned'];rows.append([short(r['run']),m['positive_proposals'],m['positive_route_hits'],f"{m['positive_proposal_precision']:.3f}",f"{m['positive_window_recall']:.3f}"])
table(rows)
para('# Training to a validation plateau')
para('The longer-horizon program selects the recipe using the mean of paired pilot validation scores across seven candidate groups, including the plain softmax model. Classical periodic features with softmax won this choice. The schedule uses repeated full validations and a six-check plateau criterion. Small improvements can give a later best checkpoint without resetting patience if they fall below the material-improvement threshold. Epochs in this study and optimizer updates in the fixed-budget pilot are different units.')
for f in sorted(here.glob('convergence-*.json')):
 width=f.stem.split('-')[-1];record=read(f.name)
 para('## Width '+width)
 para(f"The run stopped after {record['epochs']} epochs under {record['stop_reason'].replace('_',' ')}. Epoch {record['best_epoch']} had the lowest validation MAE, {num(record['best_validation']['mae_bps'])}, against {num(record['best_validation']['persistence_mae_bps'])} for persistence. Peak allocated CUDA memory reported during training and validation was {record['peak_cuda_allocated_mib_train_and_validation']:.1f} MiB.")
 rows=[['Split','MAE','Persistence','Lower 95%','Upper 95%']]
 for sp in ['test','new_asset','stress']:
  s=record['holdout'][sp];rows.append([sp.replace('new_asset','CHF'),num(s['learned']['mae_bps']),num(s['persistence']['mae_bps']),num(s['interval']['lower_95']),num(s['interval']['upper_95'])])
 table(rows)
para('The paired intervals describe prediction error in the frozen samples. Running for longer, using a learning-rate schedule and selecting a feature configuration changes multiple elements relative to the fixed-budget proxy study. Attribute differences to the complete recipe unless a matched experiment isolates one change.')
if not (here/'convergence-832.json').exists():
 para('At the cutoff for this edition, the width-832 full-epoch run was in progress. Its fixed-budget pilot checkpoint remains represented in the separate campaign ledger.')
para('The convergence run uses initialization seed 20261122 and per-epoch CPU shuffle seed 20261123 plus the epoch index. Each full epoch covers 65,536 training windows in 1,024 steps of 64. The learning rate warms up for one epoch, falls by a factor of two after every two non-material checks, and has a floor of 1/16 of its initial scale. An improvement of at least 0.0005 log bps resets patience. Stopping requires at least eight epochs, with a hard cap of 32.')
para('The live results page publishes the available convergence, campaign and ablation tables.')
para('! PhaseWeave experiment results | https://amelie-iska.github.io/phaseweave-lab/results.html')
(here/'05-ledger.txt').write_text('\n'.join(lines)+'\n')
