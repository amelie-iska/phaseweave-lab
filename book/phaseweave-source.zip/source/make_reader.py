"""Snapshot annotated math and implementation excerpts from the adjacent checkout."""
import ast
from pathlib import Path
from textwrap import dedent

here = Path(__file__).resolve().parent
repo = here.parent.parent
sections = [
("A quote snapshot", "quote_graph", ["snapshot_graph"],
 "Look for the right-sided search and the subtraction by one. An event exactly on the decision tick belongs to the information set. The graph construction retains both the quote side and the source timestamp, so a later user can audit the transformation.",
 "Change one input quote to occur a microsecond after the decision time. If no earlier quote exists, the pair should have no edges at that tick. Replacing the right-sided search with nearest-neighbor selection could import that future observation."),
("An exhaustive triangle verifier", "quote_graph", ["audit_triangles"],
 "The first stage rejects malformed graphs. A repeated endpoint pair is ambiguous under this schema because there is no venue dimension in the lookup key. The second stage quotients simple directed triangles by rotation. The exact score uses a high-accuracy sum and one cost deduction per leg.",
 "On four distinct nodes there are eight directed three-cycles modulo rotation, allowing both orientations. Check the count by choosing three nodes in four ways and two orientations. In a partial graph the verifier still reports the candidate with a missing score."),
("Constructing a timestamp stream", "histdata_quality", ["asof_quotes"],
 "The raw source files are immutable. The analysis reads quote rows, checks their digest and aggregates ties before performing time-based joins. The grouping rule is part of the observation model. A later policy using the final row of a tie would define a different source series.",
 "Consider tied bids 99 and 100 with asks 102 and 101. The conservative envelope is 99/102. This wider pair reduces both directed edge rates relative to 100/101. A two-leg round trip reflects the entire difference."),
("Sampling a supported window", "curate_margin", ["verify_window","triangle_data"],
 "The eligibility predicate is a conjunction over all three quote streams at the decision and forecast ticks. A separate condition checks that the future records arrived after the anchor. Sampling follows eligibility. Holding a fixed seed while changing the eligibility definition changes the population sampled.",
 "Trace the shapes through the nested rates function. It accepts both a two-dimensional array of history indices and a one-dimensional array of future indices. Summing along the wrong axis can produce plausible numbers of the wrong shape when a batch size happens to equal an edge count."),
("Forecast inputs, masks and pooling", "forecast", ["Forecast.forward"],
 "One batch dimension is temporarily expanded into batch times history for spatial processing. The edge mask contributes to outgoing counts, token masking and pooling. Unavailable edge logs are zeroed at curation time; the numeric zero alone cannot carry the distinction between an absent edge and a gauge-fixed tree edge.",
 "An isolated valid node token remains in the pooling denominator. Removing invalid edge features without removing them from that denominator changes the scale of the frame vector. Padding-invariance checks therefore need both the aggregation and its normalization."),
("Width-scaled projective attention", "forecast", ["width_scaled_attention","parameterize","create_optimizer"],
 "The imported transformer provides the projections and gates. This wrapper centers every head vector at its largest coordinate and normalizes it. The chosen multiplier acts after this operation. The base and delta models tell the μP library which dimensions change with width.",
 "Consider a head with all coordinates equal. Subtracting its maximum produces zero. A robust normalization returns a finite zero vector through its epsilon convention. Such a head can still have meaningful value vectors. Inspect empty valid masks separately."),
("The simulated feature and its control", "cyclic_patch", ["CyclicPatch"],
 "The shape of the joint tensor is batch by 3 by 3 by 3 by 3. Broadcasted phase terms provide local and nearest-neighbor contributions. Dividing by nine normalizes equal-magnitude amplitudes. Each probability marginal sums over three axes and leaves the measured axis intact.",
 "Set the input angles and all couplings to zero for the formula. The joint state is uniform before the orthonormal inverse transform. It concentrates at the all-zero basis vector afterward, giving real clock expectation one on every wire. The output projection can change the projected result."),
("A finite coordinate check", "campaign", ["coordinate_check"],
 "At fixed rows, seed and selected nominal multipliers the hook records the absolute mean output of the last temporal block. Each iteration's logged residual belongs to the forward pass preceding the optimizer update. The initial zero residual follows from the zero-initialized prediction head.",
 "A factor-of-twenty envelope detects catastrophic width dependence at these five widths. Smooth variation inside that envelope cannot by itself validate gradient scaling or long-run generalization. The reported table supplies the final finite readings."),
("A reproducible proxy choice", "campaign", ["launch","main"],
 "The roster product places the two seeds adjacent for each setting. The minimum pair uses its index as a deterministic tie breaker. The transfer configuration inherits the first seed in the winning pair. A validation-only selection keeps subsequent holdout comparisons interpretable.",
 "If each seed were ranked separately, a noisier hyperparameter group would get extra opportunities to win. The two-seed average reduces this selection effect, though two draws still provide limited information. Repeating the same seed at larger width tests width transfer under one optimization draw."),
("Computing population scores", "campaign_report", ["selected_records","aligned_prediction","margin_scores","block_interval"],
 "One action per row is chosen from the larger predicted margin if that margin is positive. A hit depends on the realized margin of precisely that route. The quantile of all directional absolute errors and the event hit counts summarize different parts of the output.",
 "Suppose actual margins are (0.1, −0.1) and predicted margins are (−0.1, 0.1). The row has a positive opportunity and a positive proposal, yet the chosen route misses. Evaluating only whether each row contains some positive value would incorrectly count a success."),
("Converting displayed book size", "workbench", ["gate_edges","feed_report"],
 "A positive bid size is already denominated in the input asset of the forward edge. A positive ask size is multiplied by the ask to obtain the reverse edge's input capacity. The adapter uses the provider update time and reports fetch failures separately before invoking the graph verifier.",
 "If a provider sends a timestamp later than local time, the workbench excludes the affected edges and records that symptom. A sound diagnosis would compare clocks and units before treating the sample as evidence about the market."),
("Replay decisions and denominators", "workbench", ["archive_graph","policy_report"],
 "The archive adapter reconstructs absolute quote times from stored ages relative to a frame. Replay evaluates the same chosen orientation in the immediately following recorded frame and records a missing outcome when that frame lacks usable quotes. Attempt counts and observed later outcomes can differ.",
 "Walk the code with a current positive quote followed by an unavailable future margin. The policy can record an attempted action even though it lacks a realized quote target. Replacing the missing outcome with zero would understate uncertainty and change the denominator."),
]
out = []
for title, module, names, lead, exercise in sections:
    source = (repo/'research'/f'{module}.py').read_text()
    tree = ast.parse(source)
    out += ['# '+title, lead, '## Source walkthrough', f'The excerpt is from research/{module}.py in the PhaseWeave implementation.']
    for name in names:
        node = tree
        for key in name.split('.'):
            node = next(item for item in node.body if getattr(item,'name',None)==key)
        out += ['```', dedent('\n'.join(source.splitlines()[node.lineno-1:node.end_lineno])), '```']
    out += ['## Check your interpretation', exercise, '']
(here/'07-reader.txt').write_text('\n'.join(out)+'\n')
